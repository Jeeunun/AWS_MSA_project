from django.contrib import admin
from django.urls import path, include
from django.http import HttpResponse, JsonResponse
from django.db import connection
from django.db.utils import OperationalError
import json
import os
from datetime import datetime

def health_check(request):
    """서버 상태 확인용 헬스 체크 엔드포인트"""
    return HttpResponse("OK", status=200)

def detailed_health_check(request):
    """상세한 서버 상태 확인용 헬스 체크 엔드포인트"""
    health_status = {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "server": "KBO Info Django Server",
        "version": "1.0.0"
    }
    
    # 데이터베이스 연결 상태 확인
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            health_status["database"] = "connected"
            health_status["database_status"] = "OK"
    except OperationalError:
        health_status["database"] = "disconnected"
        health_status["database_status"] = "ERROR"
        health_status["status"] = "unhealthy"
    
    # 환경 변수 확인
    health_status["environment"] = {
        "debug": os.environ.get('DEBUG', 'False'),
        "allowed_hosts": os.environ.get('ALLOWED_HOSTS', '*'),
        "aws_region": os.environ.get('AWS_DEFAULT_REGION', 'ap-northeast-2')
    }
    
    # 상태 코드 결정
    status_code = 200 if health_status["status"] == "healthy" else 503
    
    return JsonResponse(health_status, status=status_code)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('kbo.urls')),
    path('health/', health_check, name='health_check'),
    path('health/detailed/', detailed_health_check, name='detailed_health_check'),
]