from django.db import models

class Team(models.Model):
    name = models.CharField(max_length=50, unique=True)
    code = models.CharField(max_length=4, unique=True)
    founded_year = models.IntegerField(null=True, blank=True)
    founded_date = models.DateField(null=True, blank=True)
    stadium = models.CharField(max_length=100, blank=True)
    championships = models.IntegerField(default=0)

    def __str__(self) -> str:
        return f"{self.name}({self.code})"

class Manager(models.Model):
    team = models.OneToOneField(Team, on_delete=models.CASCADE, related_name='manager')
    name = models.CharField(max_length=50)
    birthday = models.DateField(null=True, blank=True)

    def __str__(self) -> str:
        return self.name

class Player(models.Model):
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='players')
    name = models.CharField(max_length=50)
    back_number = models.CharField(max_length=5, blank=True)
    position = models.CharField(max_length=20, blank=True)
    # 추가 필드
    height = models.CharField(max_length=10, blank=True)       # 예: 183cm
    weight = models.CharField(max_length=10, blank=True)       # 예: 85kg
    birthdate = models.DateField(null=True, blank=True)        # 예: 2000-01-01
    bats_throws = models.CharField(max_length=20, blank=True)  # 예: 우투우타 / 좌투우타 등 원문 저장

    # 기존 필드 유지(다른 화면에서 사용 가능)
    bats = models.CharField(max_length=10, blank=True)
    throws = models.CharField(max_length=10, blank=True)
    
    # S3 이미지 URL 필드
    image_url = models.URLField(max_length=500, blank=True, help_text="S3에 저장된 선수 이미지 URL")

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=['team', 'back_number', 'name', 'position', 'height', 'weight', 'birthdate', 'bats_throws'],
                name='unique_player_by_all_fields'
            )
        ]

    def __str__(self) -> str:
        return self.name