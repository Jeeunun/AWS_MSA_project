from django.core.management.base import BaseCommand
from django.conf import settings
from kbo.models import Player, Team
# 온프레미스 환경에서는 AWS S3를 사용하지 않음
# import boto3
import os
import requests
from urllib.parse import urlparse, unquote
import time
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import re

class Command(BaseCommand):
    help = '선수 포지션별로 이미지를 크롤링해서 S3에 저장'

    def add_arguments(self, parser):
        parser.add_argument(
            '--team',
            type=str,
            help='특정 팀만 크롤링 (팀 코드)',
        )
        parser.add_argument(
            '--position',
            type=str,
            help='특정 포지션만 크롤링 (투수, 내야수, 외야수, 포수)',
        )
        parser.add_argument(
            '--limit',
            type=int,
            default=0,
            help='크롤링할 선수 수 제한 (기본값: 0 = 모든 선수)',
        )

    def handle(self, *args, **options):
        # AWS 환경변수는 .env에서 로드되었다고 가정 (필요시 런타임 오버라이드 가능)
        aws_region = os.environ.get('AWS_DEFAULT_REGION', 'ap-northeast-2')
        
        # S3 클라이언트 생성
        s3_client = boto3.client(
            's3',
            aws_access_key_id=os.environ.get('AWS_ACCESS_KEY_ID'),
            aws_secret_access_key=os.environ.get('AWS_SECRET_ACCESS_KEY'),
            region_name=aws_region
        )
        bucket_name = os.environ.get('AWS_S3_BUCKET', '')
        public_read = os.environ.get('AWS_S3_PUBLIC_READ', 'true').lower() in ['1', 'true', 'yes']
        
        # Chrome 옵션 설정
        chrome_options = Options()
        chrome_options.add_argument('--headless')
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument('--window-size=1920,1080')
        
        try:
            driver = webdriver.Chrome(options=chrome_options)
            self._driver = driver  # 인스턴스 변수로 저장
            self.stdout.write(f'🚀 이미지 크롤링 시작: {bucket_name}')
            
            # 팀별로 선수 이미지 크롤링
            teams = Team.objects.all()
            if options['team']:
                teams = teams.filter(code=options['team'])
            
            for team in teams:
                self.stdout.write(f'\n🏟️  팀: {team.name} ({team.code})')
                
                # 팀별 선수 목록 페이지 접근 (올바른 URL 구조 사용)
                team_url = self.get_team_squad_url(team.code)
                
                try:
                    self.stdout.write(f"  🌐 페이지 접근: {team_url}")
                    driver.get(team_url)
                    time.sleep(3)  # 페이지 로딩 대기
                    
                    # 페이지 제목 확인
                    try:
                        page_title = driver.title
                        self.stdout.write(f"  📄 페이지 제목: {page_title}")
                    except:
                        pass
                    
                    # 현재 URL 확인
                    current_url = driver.current_url
                    self.stdout.write(f"  🔗 현재 URL: {current_url}")
                    
                    # 페이지 소스 일부 확인
                    try:
                        page_source = driver.page_source[:500]
                        self.stdout.write(f"  📝 페이지 소스 (처음 500자): {page_source}")
                    except:
                        pass
                    
                    # 선수 목록 찾기 (모든 포지션)
                    all_players = []
                    
                    if options['position']:
                        # 특정 포지션만 크롤링
                        all_players = self.get_team_players_by_position(driver, team, options['position'])
                    else:
                        # 모든 포지션 크롤링
                        all_players = self.get_team_players_all_positions(driver, team)
                    
                    # 제한이 설정된 경우에만 제한 적용 (0이면 모든 선수)
                    if options['limit'] > 0 and options['limit'] < len(all_players):
                        all_players = all_players[:options['limit']]
                        self.stdout.write(f"  📋 크롤링할 선수 수: {len(all_players)}명 (제한 적용)")
                    else:
                        self.stdout.write(f"  📋 크롤링할 선수 수: {len(all_players)}명 (모든 선수)")
                    
                    for i, player_info in enumerate(all_players):
                        # 선수 번호가 있으면 번호를 포함하여 표시
                        if 'number' in player_info and player_info['number'] and player_info['number'] != '00':
                            self.stdout.write(f"  👤 {i+1}/{len(all_players)}: {player_info['number']}번 {player_info['name']} ({player_info['position']})")
                        else:
                            self.stdout.write(f"  👤 {i+1}/{len(all_players)}: {player_info['name']} ({player_info['position']})")
                        
                        # 이미지 크롤링 및 S3 업로드
                        success = self.crawl_and_upload_player_image(
                            driver, s3_client, bucket_name, team, player_info
                        )
                        
                        if success:
                            self.stdout.write(f"    ✅ 이미지 업로드 성공")
                        else:
                            self.stdout.write(f"    ❌ 이미지 업로드 실패")
                        
                        # 데이터베이스 업데이트
                        self.update_player_image_url(team, player_info['name'], bucket_name, player_info)
                        
                        # 크롤링 간격 조절
                        time.sleep(1)
                    
                except Exception as e:
                    self.stdout.write(f"  ❌ 팀 {team.name} 크롤링 실패: {e}")
                    continue
            
            self.stdout.write('\n🎉 이미지 크롤링 완료!')
            
        except Exception as e:
            self.stdout.write(f'❌ 크롤링 실패: {e}')
        finally:
            if 'driver' in locals():
                driver.quit()

    def get_team_squad_url(self, team_code, position=None):
        """팀 코드에 따른 올바른 squad URL 생성 (fetch_kbo2.py와 동일)"""
        # fetch_kbo2.py의 DAUM_TEAM_ID_MAP과 동일
        team_urls = {
            'KIA': 'https://sports.daum.net/team/kbo/389/squad',
            'LG': 'https://sports.daum.net/team/kbo/387/squad', 
            'SSG': 'https://sports.daum.net/team/kbo/384/squad',
            'KT': 'https://sports.daum.net/team/kbo/394601/squad',
            'NC': 'https://sports.daum.net/team/kbo/172615/squad',
            'DS': 'https://sports.daum.net/team/kbo/385/squad',  # 두산
            'SS': 'https://sports.daum.net/team/kbo/383/squad',  # 삼성
            'HH': 'https://sports.daum.net/team/kbo/390/squad',  # 한화
            'LT': 'https://sports.daum.net/team/kbo/386/squad',  # 롯데
            'WO': 'https://sports.daum.net/team/kbo/382/squad'   # 키움
        }
        
        base_url = team_urls.get(team_code, f'https://sports.daum.net/team/kbo/389/squad')
        
        # 포지션별 URL 파라미터 추가
        if position:
            position_mapping = {
                '투수': 'P',
                '내야수': 'IF', 
                '외야수': 'OF',
                '포수': 'C'
            }
            position_code = position_mapping.get(position, position)
            return f"{base_url}#{position_code}"
        
        return f"{base_url}#0"  # 기본값 (투수)

    def click_position_tab(self, driver, position):
        """포지션 탭 클릭"""
        try:
            # 포지션별 라디오 버튼 찾기
            position_mapping = {
                '투수': 'P',
                '내야수': 'IF', 
                '외야수': 'OF',
                '포수': 'C'
            }
            
            position_code = position_mapping.get(position, position)
            
            self.stdout.write(f"        🔍 {position} ({position_code}) 탭 찾는 중...")
            
            # 방법 1: data-position 속성으로 찾기 (스크린샷에서 확인된 구조)
            data_position_selectors = [
                f'div[data-position="{position_code}"]',
                f'div.toggle_input[data-position="{position_code}"]',
                f'div[data-position="{position_code}"] input[type="radio"]',
                f'div[data-position="{position_code}"] label'
            ]
            
            for selector in data_position_selectors:
                try:
                    elements = driver.find_elements(By.CSS_SELECTOR, selector)
                    if elements:
                        # div 자체를 클릭하거나 내부의 라디오/라벨 클릭
                        for element in elements:
                            try:
                                element.click()
                                self.stdout.write(f"        ✅ {position} ({position_code}) data-position 클릭 성공")
                                return True
                            except:
                                continue
                except:
                    continue
            
            # 방법 2: 라벨 텍스트로 찾기
            label_text_selectors = [
                f'label.lab_radio:contains("{position}")',
                f'label:contains("{position}")',
                f'span:contains("{position}")'
            ]
            
            for selector in label_text_selectors:
                try:
                    labels = driver.find_elements(By.CSS_SELECTOR, selector)
                    if labels:
                        labels[0].click()
                        self.stdout.write(f"        ✅ {position} 라벨 텍스트 클릭 성공")
                        return True
                except:
                    continue
            
            # 방법 3: JavaScript로 직접 클릭 시도
            try:
                # data-position 속성을 가진 div 찾기
                js_script = f"""
                var elements = document.querySelectorAll('div[data-position="{position_code}"]');
                if (elements.length > 0) {{
                    elements[0].click();
                    return true;
                }}
                return false;
                """
                
                result = driver.execute_script(js_script)
                if result:
                    self.stdout.write(f"        ✅ {position} ({position_code}) JavaScript data-position 클릭 성공")
                    return True
                    
            except Exception as e:
                self.stdout.write(f"        ⚠️  JavaScript data-position 클릭 실패: {e}")
            
            # 방법 4: 모든 포지션 요소 분석
            try:
                all_toggle_inputs = driver.find_elements(By.CSS_SELECTOR, 'div.toggle_input')
                self.stdout.write(f"        🔍 페이지에서 {len(all_toggle_inputs)}개의 toggle_input 발견")
                
                for i, toggle in enumerate(all_toggle_inputs):
                    try:
                        data_pos = toggle.get_attribute('data-position')
                        class_attr = toggle.get_attribute('class')
                        self.stdout.write(f"        📍 toggle {i+1}: data-position='{data_pos}', class='{class_attr}'")
                        
                        if data_pos == position_code:
                            toggle.click()
                            self.stdout.write(f"        ✅ {position} ({position_code}) toggle_input 클릭 성공")
                            return True
                    except Exception as e:
                        self.stdout.write(f"        ⚠️  toggle {i+1} 분석 실패: {e}")
                        continue
                        
            except Exception as e:
                self.stdout.write(f"        ⚠️  toggle_input 분석 실패: {e}")
            
            self.stdout.write(f"        ❌ {position} ({position_code}) 탭을 찾을 수 없음")
            return False
            
        except Exception as e:
            self.stdout.write(f"        ❌ {position} 탭 클릭 실패: {e}")
            return False

    def get_team_players_by_position(self, driver, team, position):
        """특정 포지션의 선수만 가져오기"""
        self.stdout.write(f"    🎯 {position} 포지션 선수만 크롤링...")
        return self.get_team_players(driver, team, position_filter=position)

    def get_team_players_all_positions(self, driver, team):
        """모든 포지션의 선수를 가져오기"""
        self.stdout.write(f"    🌟 모든 포지션 선수 목록 수집 중...")
        all_players = []
        
        # 먼저 기본 페이지(투수)로 이동
        base_url = self.get_team_squad_url(team.code)
        self.stdout.write(f"      🌐 기본 페이지 이동: {base_url}")
        driver.get(base_url)
        time.sleep(3)  # 페이지 로딩 대기
        
        # 포지션별로 선수 목록만 수집 (번호 추출은 나중에)
        positions = ['투수', '내야수', '외야수', '포수']
        
        for position in positions:
            self.stdout.write(f"      📍 {position} 포지션 선수 목록 수집 중...")
            
            try:
                # 포지션 탭 클릭 (첫 번째는 이미 투수 페이지이므로 클릭 불필요)
                if position != '투수':
                    if self.click_position_tab(driver, position):
                        time.sleep(2)  # 콘텐츠 변경 대기
                    else:
                        self.stdout.write(f"        ⚠️  {position} 탭 클릭 실패, 건너뜀")
                        continue
                
                # 현재 페이지에서 선수 목록만 찾기 (번호 추출 없이)
                position_players = self.find_players_from_links_no_number(driver)
                if not position_players:
                    position_players = self.find_players_from_images_no_number(driver)
                
                if position_players:
                    all_players.extend(position_players)
                    self.stdout.write(f"        ✅ {position}: {len(position_players)}명 발견")
                else:
                    self.stdout.write(f"        ⚠️  {position}: 선수 없음")
                    
            except Exception as e:
                self.stdout.write(f"        ❌ {position} 포지션 크롤링 실패: {e}")
                continue
        
        # 중복 제거 (같은 선수가 여러 포지션에 있을 수 있음)
        unique_players = []
        seen_names = set()
        for player in all_players:
            if player['name'] not in seen_names:
                unique_players.append(player)
                seen_names.add(player['name'])
        
        self.stdout.write(f"      📊 총 {len(unique_players)}명의 고유한 선수 발견")
        return unique_players

    def get_team_players(self, driver, team, position_filter=None):
        """팀 페이지에서 선수 정보 추출"""
        players = []
        
        try:
            self.stdout.write(f"    🔍 선수 목록 추출 시작...")
            
            # 포지션 필터가 있으면 해당 포지션 탭 클릭
            if position_filter:
                if self.click_position_tab(driver, position_filter):
                    time.sleep(2)  # 콘텐츠 변경 대기
                    self.stdout.write(f"        ✅ {position_filter} 포지션 탭 클릭 성공")
                else:
                    self.stdout.write(f"        ⚠️  {position_filter} 포지션 탭 클릭 실패")
            
            # 방법 1: 링크에서 선수 찾기 (우선순위 1)
            self.stdout.write(f"    🔗 방법 1: 링크에서 선수 찾기")
            link_players = self.find_players_from_links_no_number(driver)  # 번호 추출 없이
            if link_players:
                players.extend(link_players)
                self.stdout.write(f"      ✅ 링크에서 {len(link_players)}명 발견")
            
            # 방법 2: 이미지에서 선수 찾기 (링크에서 못 찾은 경우만)
            if not players:
                self.stdout.write(f"    🖼️  방법 2: 이미지에서 선수 찾기")
                image_players = self.find_players_from_images_no_number(driver)  # 번호 추출 없이
                if image_players:
                    players.extend(image_players)
                    self.stdout.write(f"      ✅ 이미지에서 {len(image_players)}명 발견")
            
            # 중복 제거
            unique_players = []
            seen_names = set()
            for player in players:
                if player['name'] not in seen_names:
                    unique_players.append(player)
                    seen_names.add(player['name'])
            
            self.stdout.write(f"    📋 최종 선수 수: {len(unique_players)}명")
            return unique_players
            
        except Exception as e:
            self.stdout.write(f"    ❌ 선수 목록 추출 실패: {e}")
            return []



    def find_players_from_links_no_number(self, driver):
        """링크에서 선수 정보 추출 (번호 추출 없이)"""
        players = []
        try:
            # 선수 관련 링크 찾기
            links = driver.find_elements(By.CSS_SELECTOR, 'a[href*="player"]')
            
            for link in links:
                try:
                    href = link.get_attribute('href')
                    text = link.text.strip()
                    
                    if text and href and len(text) < 20:  # 이름은 보통 짧음
                        # URL에서 선수 ID 추출 시도
                        if 'player' in href:
                            players.append({
                                'number': '00',  # 나중에 추출
                                'name': text,
                                'position': '미정',
                                'url': href
                            })
                            
                except Exception as e:
                    continue
            
        except Exception as e:
            self.stdout.write(f"      ⚠️  링크에서 선수 찾기 실패: {e}")
        
        return players

    def find_players_from_links(self, driver):
        """링크에서 선수 정보 추출 (번호 포함)"""
        players = []
        try:
            # 선수 관련 링크 찾기
            links = driver.find_elements(By.CSS_SELECTOR, 'a[href*="player"]')
            
            for link in links:
                try:
                    href = link.get_attribute('href')
                    text = link.text.strip()
                    
                    if text and href and len(text) < 20:  # 이름은 보통 짧음
                        # URL에서 선수 ID 추출 시도
                        if 'player' in href:
                            # 선수 상세 페이지에서 번호 추출
                            player_number = self.extract_player_number_from_detail_page(driver, href)
                            
                            players.append({
                                'number': player_number,
                                'name': text,
                                'position': '미정',
                                'url': href
                            })
                            
                except Exception as e:
                    continue
            
        except Exception as e:
            self.stdout.write(f"      ⚠️  링크에서 선수 찾기 실패: {e}")
        
        return players

    def extract_player_number_from_detail_page(self, driver, player_url):
        """선수 상세 페이지에서 등번호 추출"""
        try:
            # 현재 페이지 저장
            current_url = driver.current_url
            
            # 선수 상세 페이지로 이동
            driver.get(player_url)
            time.sleep(2)  # 페이지 로딩 대기
            
            # 등번호 찾기 (스크린샷에서 확인된 구조)
            number_selectors = [
                'span.txt_info',  # "No.0 좌투좌타" 텍스트가 있는 span
                '.txt_info',      # txt_info 클래스
                'span:contains("No.")',  # "No."가 포함된 span
                'span:contains("번")',   # "번"이 포함된 span
            ]
            
            player_number = '00'  # 기본값
            
            for selector in number_selectors:
                try:
                    elements = driver.find_elements(By.CSS_SELECTOR, selector)
                    for element in elements:
                        text = element.get_attribute('textContent').strip()
                        if text:
                            # "No.0" 또는 "0번" 형태에서 숫자 추출
                            number_match = re.search(r'No\.(\d+)|(\d+)번', text)
                            if number_match:
                                # 첫 번째 그룹이 매치되면 사용, 아니면 두 번째 그룹 사용
                                extracted_number = number_match.group(1) or number_match.group(2)
                                if extracted_number and extracted_number.isdigit():
                                    player_number = extracted_number
                                    self.stdout.write(f"        🔢 등번호 추출: '{text}' -> '{player_number}'")
                                    break
                except:
                    continue
                
                if player_number != '00':
                    break
            
            # 원래 페이지로 복귀
            driver.get(current_url)
            time.sleep(1)  # 페이지 로딩 대기
            
            return player_number
            
        except Exception as e:
            self.stdout.write(f"        ⚠️  등번호 추출 실패: {e}")
            # 원래 페이지로 복귀 시도
            try:
                driver.get(current_url)
                time.sleep(1)
            except:
                pass
            return '00'

    def find_players_from_images_no_number(self, driver):
        """이미지에서 선수 정보 추출 (번호 추출 없이)"""
        players = []
        try:
            # 선수 이미지 찾기
            images = driver.find_elements(By.CSS_SELECTOR, 'img[alt*="선수"], img[src*="player"]')
            
            for img in images:
                try:
                    alt = img.get_attribute('alt')
                    src = img.get_attribute('src')
                    
                    if alt and '선수' in alt:
                        # alt에서 선수 이름 추출
                        name = alt.replace('선수', '').strip()
                        if name and len(name) < 20:
                            # 부모 요소에서 링크 찾기
                            try:
                                parent_link = img.find_element(By.XPATH, './ancestor::a[1]')
                                url = parent_link.get_attribute('href')
                                if url:
                                    players.append({
                                        'number': '00',  # 나중에 추출
                                        'name': name,
                                        'position': '미정',
                                        'url': url
                                    })
                            except:
                                pass
                            
                except Exception as e:
                    continue
            
        except Exception as e:
            self.stdout.write(f"      ⚠️  이미지에서 선수 찾기 실패: {e}")
        
        return players

    def find_players_from_images(self, driver):
        """이미지에서 선수 정보 추출 (번호 포함)"""
        players = []
        try:
            # 선수 이미지 찾기
            images = driver.find_elements(By.CSS_SELECTOR, 'img[alt*="선수"], img[src*="player"]')
            
            for img in images:
                try:
                    alt = img.get_attribute('alt')
                    src = img.get_attribute('src')
                    
                    if alt and '선수' in alt:
                        # alt에서 선수 이름 추출
                        name = alt.replace('선수', '').strip()
                        if name and len(name) < 20:
                            # 부모 요소에서 링크 찾기
                            try:
                                parent_link = img.find_element(By.XPATH, './ancestor::a[1]')
                                url = parent_link.get_attribute('href')
                                if url:
                                    # 선수 상세 페이지에서 번호 추출
                                    player_number = self.extract_player_number_from_detail_page(driver, url)
                                    
                                    players.append({
                                        'number': player_number,
                                        'name': '미정',
                                        'position': '미정',
                                        'url': url
                                    })
                            except:
                                pass
                            
                except Exception as e:
                    continue
            
        except Exception as e:
            self.stdout.write(f"      ⚠️  이미지에서 선수 찾기 실패: {e}")
        
        return players

    def crawl_and_upload_player_image(self, driver, s3_client, bucket_name, team, player_info):
        """선수 이미지 크롤링 및 S3 업로드"""
        try:
            # 선수 상세 페이지 접근
            driver.get(player_info['url'])
            time.sleep(2)
            
            # 선수 상세 페이지에서 번호 추출 (스크린샷 참고)
            player_number = self.extract_player_number_from_detail_page(driver, player_info['url'])
            
            # 이미지 찾기
            image_url = self.find_player_image(driver)
            
            if not image_url:
                self.stdout.write(f"      ⚠️  이미지를 찾을 수 없음")
                return False
            
            # 이미지 다운로드
            image_data = self.download_image(image_url)
            if not image_data:
                return False
            
            # S3에 업로드 (추출된 번호로 파일명 생성)
            if player_number and player_number != '00':
                s3_key = f"players/{team.code}/{player_number}_{player_info['name']}.jpg"
                self.stdout.write(f"      🔢 선수 번호: {player_number}번")
            else:
                s3_key = f"players/{team.code}/{player_info['name']}.jpg"
                self.stdout.write(f"      ⚠️  번호 추출 실패, 기본 파일명 사용")
            
            put_args = {
                Bucket=bucket_name,
                Key=s3_key,
                Body=image_data,
                ContentType='image/jpeg',
                CacheControl='public, max-age=31536000'
            }
            if public_read:
                put_args['ACL'] = 'public-read'
            s3_client.put_object(**put_args)
            
            self.stdout.write(f"      📸 이미지 저장: {s3_key}")
            return True
            
        except Exception as e:
            self.stdout.write(f"      ❌ 이미지 크롤링 실패: {e}")
            return False

    def find_player_image(self, driver):
        """선수 상세 페이지에서 이미지 URL 찾기"""
        try:
            # 여러 가능한 이미지 선택자 시도
            selectors = [
                'img.thumb_g',  # 현재 페이지에서 보이는 이미지
                'img[src*="player"]',  # player가 포함된 src
                'img[src*="sports"]',  # sports가 포함된 src
                '.player-image img',  # 선수 이미지 클래스
                'img[alt*="선수"]'  # alt에 선수가 포함된 이미지
            ]
            
            for selector in selectors:
                try:
                    img_elem = driver.find_element(By.CSS_SELECTOR, selector)
                    src = img_elem.get_attribute('src')
                    
                    if src and ('player' in src or 'sports' in src):
                        # 상대 URL을 절대 URL로 변환
                        if src.startswith('//'):
                            src = 'https:' + src
                        elif src.startswith('/'):
                            src = 'https://sports.daum.net' + src
                        
                        return src
                        
                except NoSuchElementException:
                    continue
            
            return None
            
        except Exception as e:
            return None

    def download_image(self, image_url):
        """이미지 다운로드"""
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            }
            
            response = requests.get(image_url, headers=headers, timeout=10)
            response.raise_for_status()
            
            return response.content
            
        except Exception as e:
            return None

    def update_player_image_url(self, team, player_name, bucket_name, player_info):
        """데이터베이스의 선수 이미지 URL 업데이트"""
        try:
            player = Player.objects.filter(team=team, name=player_name).first()
            if player:
                # 선수 상세 페이지에서 번호를 다시 추출하여 S3 URL 생성
                driver = getattr(self, '_driver', None)
                if driver:
                    player_number = self.extract_player_number_from_detail_page(driver, player_info['url'])
                    if player_number and player_number != '00':
                        s3_url = f"https://{bucket_name}.s3.ap-northeast-2.amazonaws.com/players/{team.code}/{player_number}_{player_name}.jpg"
                    else:
                        s3_url = f"https://{bucket_name}.s3.ap-northeast-2.amazonaws.com/players/{team.code}/{player_name}.jpg"
                else:
                    # driver가 없으면 기본 URL 생성
                    s3_url = f"https://{bucket_name}.s3.ap-northeast-2.amazonaws.com/players/{team.code}/{player_name}.jpg"
                
                player.image_url = s3_url
                player.save()
                
        except Exception as e:
            self.stdout.write(f"      ⚠️  DB 업데이트 실패: {e}")
