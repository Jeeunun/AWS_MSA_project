#!/usr/bin/env bash
set -euxo pipefail

# KBO 정보 서비스 자동 설치 및 크롤링 스크립트
# 리눅스 환경 전용 (Amazon Linux 2023, RHEL, CentOS, Ubuntu, Debian)

# 버전 정보
SCRIPT_VERSION="2.0.0"

# 경로 설정
APP_ROOT=${APP_ROOT:-$(pwd)}
# test.sh가 new 디렉토리 안에서 실행되더라도 올바른 경로 찾기
if [[ "$(basename $(pwd))" == "new" ]]; then
    CODE_DIR=${CODE_DIR:-$(pwd)}
else
    CODE_DIR=${CODE_DIR:-$(pwd)/new}
fi

# 환경변수 및 설정

# 환경변수 파일 자동 로드
load_environment() {
    local env_candidates=(
        "${CODE_DIR}/kbo_crawler/.env"
        "${CODE_DIR}/kbo_crawler/.env.txt"
        "${CODE_DIR}/.env"
        "${CODE_DIR}/env.txt"
    )
    
    for env_file in "${env_candidates[@]}"; do
        if [[ -f "${env_file}" ]]; then
                    printf "[INFO] 환경변수 파일 로드: %s\n" "${env_file}"
        printf "==================================\n"
            set -a
            source "${env_file}"
            set +a
            return 0
        fi
    done
    
    printf "[WARNING] 환경변수 파일을 찾을 수 없습니다. 기본값을 사용합니다.\n"
    return 1
}

    # 데이터베이스 설정
    DB_NAME=${DB_NAME:-kbo_db}
    DB_USER=${DB_USER:-root}
    DB_PASSWORD=${DB_PASSWORD:-test}
    DB_PORT=${DB_PORT:-3306}

# 기본 호스트 설정
DB_HOST=${DB_HOST:-localhost}

# 유틸리티 함수들

# 로그 함수들
log_info() { printf "[INFO] %s\n" "$1"; }
log_success() { printf "[SUCCESS] %s\n" "$1"; }
log_warning() { printf "[WARNING] %s\n" "$1"; }
log_error() { printf "[ERROR] %s\n" "$1"; }
log_step() { 
    echo ""
    echo "=================================="
    echo "STEP: $1"
    echo "=================================="
    echo ""
}

# MariaDB 사용자 생성 및 설정 함수 (root 사용하지 않음)
create_mariadb_user() {
    log_info "MariaDB 사용자 생성 및 설정 중..."
    
    # MariaDB 서비스 상태 확인
    if ! sudo systemctl is-active --quiet mariadb; then
        log_error "MariaDB 서비스가 실행되지 않음"
        return 1
    fi
    
    # kbo_user 사용자 생성 시도
    if mariadb -u root -e "CREATE USER IF NOT EXISTS 'kbo_user'@'localhost' IDENTIFIED BY 'test';" 2>/dev/null; then
        log_success "kbo_user 사용자 생성 완료"
    else
        log_warning "kbo_user 사용자 생성 실패, 기존 사용자 사용"
    fi
    
    # 데이터베이스 생성
    if mariadb -u root -e "CREATE DATABASE IF NOT EXISTS ${DB_NAME} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" 2>/dev/null; then
        log_success "데이터베이스 ${DB_NAME} 생성 완료"
    else
        log_warning "데이터베이스 생성 실패, 기존 데이터베이스 사용"
    fi
    
    # 권한 부여
    mariadb -u root -e "GRANT ALL PRIVILEGES ON ${DB_NAME}.* TO 'kbo_user'@'localhost';" 2>/dev/null
    mariadb -u root -e "FLUSH PRIVILEGES;" 2>/dev/null
    log_success "kbo_user 권한 설정 완료"
    
    # 환경변수 설정
    export DB_USER="kbo_user"
    export DB_PASSWORD="test"
    log_info "데이터베이스 사용자를 kbo_user로 설정했습니다"
}

# 데이터베이스 및 사용자 설정 함수
setup_database_and_user() {
    # MariaDB 서비스 상태 확인
    if ! sudo systemctl is-active --quiet mariadb; then
        log_error "MariaDB 서비스가 실행되지 않음, setup_database_and_user를 실행할 수 없습니다"
        return 1
    fi
    
    # 기본 데이터베이스 생성 (sudo 사용)
    log_info "기본 데이터베이스 생성 중..."
    if sudo mariadb -u root -e "CREATE DATABASE IF NOT EXISTS ${DB_NAME} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" 2>/dev/null; then
        log_success "데이터베이스 ${DB_NAME} 생성 완료"
    else
        log_warning "데이터베이스 생성 실패, 기존 데이터베이스 사용"
    fi
    
    # kbo_user 사용자 생성 및 권한 부여 (sudo 사용)
    log_info "kbo_user 사용자 생성 및 권한 부여 중..."
    sudo mariadb -u root -e "CREATE USER IF NOT EXISTS 'kbo_user'@'localhost' IDENTIFIED BY 'test';" 2>/dev/null
    sudo mariadb -u root -e "GRANT ALL PRIVILEGES ON ${DB_NAME}.* TO 'kbo_user'@'localhost';" 2>/dev/null
    sudo mariadb -u root -e "FLUSH PRIVILEGES;" 2>/dev/null
    log_success "kbo_user 사용자 설정 완료"
    
    # 환경변수 업데이트
    export DB_USER="kbo_user"
    export DB_PASSWORD="test"
    log_info "데이터베이스 사용자를 kbo_user로 변경했습니다"
}

# 프로세스 정리 함수들
cleanup_chrome() {
    log_info "Chrome 프로세스 정리 중..."
    pkill -f chrome || true
    pkill -f chromium || true
    pkill -f chromedriver || true
    sleep 2
    log_success "Chrome 프로세스 정리 완료"
}

cleanup_django_server() {
    log_info "Django 서버 정리 중..."
    pkill -f "python manage.py runserver" || true
    pkill -f "gunicorn" || true
    sleep 3
    log_success "Django 서버 정리 완료"
}

# 시스템 상태 확인 함수들
check_memory() {
    log_info "메모리 상태:"
    free -h
    echo "시스템 부하:"
    uptime
    echo ""
}

check_django_server() {
    log_info "Django 서버 상태 확인 중..."
    
    # curl 또는 wget을 사용하여 서버 상태 확인
    if command -v curl >/dev/null 2>&1; then
        if curl -s -o /dev/null -w "%{http_code}" http://localhost:8000/players | grep -q "200"; then
            log_success "Django 서버 정상 실행 중"
            return 0
        else
            log_warning "Django 서버 응답 없음"
            return 1
        fi
    elif command -v wget >/dev/null 2>&1; then
        if wget -q -O /dev/null --server-response http://localhost:8000/players 2>&1 | grep -q "HTTP/.* 200"; then
            log_success "Django 서버 정상 실행 중"
            return 0
        else
            log_warning "Django 서버 응답 없음"
            return 1
        fi
    else
        log_warning "curl 또는 wget이 없어 서버 상태를 확인할 수 없습니다"
        return 1
    fi
}

# 패키지 관리자 감지 및 설치 함수

detect_package_manager() {
    if command -v dnf >/dev/null 2>&1; then
        echo "dnf"
    elif command -v apt >/dev/null 2>&1; then
        echo "apt"
    elif command -v yum >/dev/null 2>&1; then
        echo "yum"
    else
        echo "unknown"
    fi
}

install_system_packages() {
    local pkg_manager=$(detect_package_manager)
    
    case $pkg_manager in
        "dnf")
            log_info "Amazon Linux 2023/RHEL/CentOS용 패키지 설치 중..."
            sudo dnf -y update
            
            # curl 패키지 충돌 해결
            if dnf list installed | grep -q "curl-minimal"; then
                log_info "curl-minimal 제거 중..."
                sudo dnf remove -y curl-minimal || true
                # 시스템 정리
                sudo dnf -y autoremove
            fi
            
            # curl 설치 시 충돌 방지
            sudo dnf -y install unzip wget tar rsync --allowerasing
            # curl 설치 시도 (여러 방법으로)
            if ! sudo dnf -y install curl --allowerasing; then
                log_warning "curl 설치 실패, --skip-broken으로 재시도..."
                sudo dnf -y install curl --skip-broken || {
                    log_warning "curl 설치 실패, wget으로 대체..."
                    # curl이 설치되지 않아도 wget이 있으면 계속 진행
                }
            fi
            # Python 3.13 명시 설치
            sudo dnf -y install python3.13 python3.13-pip python3.13-devel
            sudo dnf -y install libxml2-devel libxslt-devel gcc python3-devel
            sudo dnf -y install mariadb105-server mariadb105-devel mariadb105
            ;;
        "apt")
            log_info "Ubuntu/Debian용 패키지 설치 중..."
            sudo apt update
            sudo apt install -y unzip wget tar rsync curl build-essential python3-dev
            sudo apt install -y libxml2-dev libxslt-dev mysql-client libmysqlclient-dev
            ;;
        "yum")
            log_info "CentOS 7용 패키지 설치 중..."
            sudo yum -y update
            sudo yum -y install unzip wget tar rsync curl gcc python3-devel
            sudo yum -y install libxml2-devel libxslt-devel mariadb105-server mariadb105-devel
            ;;
        *)
            log_error "지원하지 않는 패키지 관리자입니다"
            return 1
            ;;
    esac
}

# Python 설치 및 설정



# Chrome 및 Chromedriver 설치 (간소화)

install_chrome() {
    log_step "Chrome 설치"
    
    if command -v google-chrome >/dev/null 2>&1 || command -v chromium >/dev/null 2>&1; then
        log_success "Chrome/Chromium이 이미 설치되어 있습니다"
        return 0
    fi
    
    local pkg_manager=$(detect_package_manager)
    
    case $pkg_manager in
        "dnf"|"yum")
            log_info "Chromium 설치 중..."
            sudo $pkg_manager -y install chromium || true
            ;;
    esac
    
    log_success "Chrome/Chromium 설치 완료"
}

install_chromedriver() {
    log_step "Chromedriver 설치"
    
    if command -v chromedriver >/dev/null 2>&1; then
        log_success "Chromedriver가 이미 설치되어 있습니다"
        return 0
    fi
    
    local pkg_manager=$(detect_package_manager)
    
    case $pkg_manager in
        "dnf"|"yum")
            log_info "Chromedriver 설치 중..."
            sudo $pkg_manager -y install chromedriver || sudo $pkg_manager -y install chromium-driver || true
            ;;
    esac
    
    log_success "Chromedriver 설치 완료"
}

# 가상환경 및 의존성 설치

setup_virtual_environment() {
    # 단계 시작 표시
    log_step "가상환경 및 의존성 설치"
    
    # 작업 디렉토리로 이동
    cd "${CODE_DIR}"
    
    # 가상환경 생성
    log_info "가상환경 생성 중..."
    # 사용할 Python 선택 (우선순위: 3.13 -> 3.12 -> 3.11 -> 3.10)
    SELECTED_PY=""
    for cand in python3.13 python3.12 python3.11 python3.10; do
        if command -v "$cand" >/dev/null 2>&1; then
            SELECTED_PY="$cand"
            break
        fi
    done
    # 없으면 시스템 python3 사용 (경고)
    if [[ -z "$SELECTED_PY" ]]; then
        if command -v python3 >/dev/null 2>&1; then
            SELECTED_PY="python3"
            log_warning "특정 버전 Python을 찾지 못해 python3를 사용합니다"
        else
            log_error "사용할 Python 인터프리터를 찾을 수 없습니다"
            return 1
        fi
    fi

    # 기존 venv가 있고 Python<3.10 이면 제거 후 재생성
    if [[ -d venv ]]; then
        source venv/bin/activate
        if ! python -c "import sys; exit(0 if sys.version_info[:2] >= (3,10) else 1)"; then
            deactivate || true
            rm -rf venv
        else
            deactivate || true
        fi
    fi

    if [[ ! -d venv ]]; then
        log_info "가상환경 생성 명령어: ${SELECTED_PY} -m venv venv"
        ${SELECTED_PY} -m venv venv
    fi
    source venv/bin/activate
    
    # pip 업그레이드 (python -m pip 사용)
    log_info "pip 업그레이드 중..."
    python -m pip install -U pip setuptools wheel
    
    # 의존성 설치
    # Python 버전에 따라 Django 스펙 결정
    DJANGO_SPEC="Django==5.2.4"
    if ! python -c "import sys; exit(0 if sys.version_info[:2] >= (3,10) else 1)"; then
        DJANGO_SPEC="Django==4.2.*"
        log_warning "Python<3.10 감지됨. Django 4.2 LTS로 대체 설치합니다 (${DJANGO_SPEC})"
    fi

    log_info "의존성 설치 중..."
    # 1차: 표준 설치 시도
    if python -m pip install -r requirements.txt; then
        log_success "의존성 설치 성공"
    else
        log_warning "일부 패키지 설치 실패, 개별 설치 시도..."
        
        # 핵심 패키지들 개별 설치
        python -m pip install "${DJANGO_SPEC}" selenium==4.33.0 beautifulsoup4==4.12.3 || true
        python -m pip install requests==2.31.0 gunicorn==22.0.0 boto3==1.34.69 || true
        python -m pip install typing-extensions || true
        
        # MariaDB 의존성 특별 처리
        log_info "MariaDB 의존성 설치 중..."
        if ! python -m pip install PyMySQL==1.1.0; then
            log_warning "PyMySQL 설치 실패, 대체 패키지 시도 중..."
            
            # 시스템 의존성 설치
            local pkg_manager=$(detect_package_manager)
            case $pkg_manager in
                "dnf"|"yum")
                    sudo $pkg_manager install -y mariadb105-devel gcc python3-devel
                    ;;
                "apt")
                    sudo apt install -y libmysqlclient-dev gcc python3-dev
                    ;;
            esac
            
            if ! python -m pip install PyMySQL; then
                log_error "MariaDB 의존성 설치 실패"
                return 1
            fi
        fi
        
        log_success "MariaDB 의존성 설치 완료"
        
        # PyMySQL Django 연동 검증
        log_info "PyMySQL Django 연동 검증 중..."
        if python -c "import pymysql; pymysql.install_as_MySQLdb(); print('PyMySQL Django 연동 성공')" 2>/dev/null; then
            log_success "PyMySQL Django 연동 성공"
        else
            log_warning "PyMySQL Django 연동 실패, Django 마이그레이션에서 문제 발생 가능"
        fi
        
        # MariaDB 서비스 시작 안내
        log_info "MariaDB 설치 완료! 다음 단계를 진행하세요:"
        log_info "1. MariaDB 서비스 시작: sudo systemctl start mariadb105"
        log_info "2. 서비스 활성화: sudo systemctl enable mariadb105"
        log_info "3. 보안 설정: sudo mysql_secure_installation"
        log_info "4. 데이터베이스 생성: mariadb -u root -p -e 'CREATE DATABASE kbo_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;'"
    fi

    # 설치 검증: Django import 확인 및 버전 출력
    if python - <<'PY'
import sys
try:
    import django
    print("[INFO] Django 설치 확인:", django.get_version())
    sys.exit(0)
except Exception as e:
    print("[ERROR] Django import 실패:", e)
    sys.exit(1)
PY
    then
        log_success "Django 설치 검증 완료"
    else
        log_warning "Django 설치 검증 실패, 재시도 진행..."
        # 캐시 비우고 재시도
        python -m pip cache purge || true
        python -m pip install -r requirements.txt || true
        python - <<'PY'
import sys
try:
    import django
    print("[INFO] Django 재검증:", django.get_version())
    sys.exit(0)
except Exception as e:
    print("[ERROR] Django 재검증 실패:", e)
    sys.exit(1)
PY
    fi
    
    log_success "의존성 설치 완료"
}

# 데이터베이스 설정 및 마이그레이션

setup_database() {
    log_step "데이터베이스 설정 및 마이그레이션"
    
    cd "${CODE_DIR}"
    source venv/bin/activate
    
    # MariaDB 서비스 자동 시작 및 설정
    log_info "MariaDB 서비스 상태 확인 및 시작 중..."
    
    # MariaDB 서버 패키지 설치 확인 및 설치
    if ! rpm -q mariadb105-server >/dev/null 2>&1; then
        log_warning "MariaDB 서버 패키지가 설치되지 않음, 설치 중..."
        
        # MariaDB 서버 패키지 설치
        if sudo dnf install -y mariadb105-server mariadb105-devel mariadb105; then
            log_success "MariaDB 서버 패키지 설치 완료"
        else
            log_error "MariaDB 서버 패키지 설치 실패"
            return 1
        fi
    else
        log_success "MariaDB 서버 패키지가 이미 설치되어 있습니다"
    fi
    
    # 기본 mariadb.service 사용 (Amazon Linux 2023 기본 제공)
    log_info "기본 mariadb.service 사용 중..."
    
    # MariaDB 초기화 (첫 설치 시에만)
    log_info "MariaDB 초기화 중..."
    if [[ ! -d /var/lib/mysql/mysql ]]; then
        log_info "MariaDB 데이터베이스 초기화 중..."
        sudo mariadb-install-db --user=mysql --datadir=/var/lib/mysql || true
        
        # 데이터 디렉토리 권한 설정
        sudo chown -R mysql:mysql /var/lib/mysql
        sudo chown -R mysql:mysql /var/log/mariadb
        sudo chown -R mysql:mysql /var/run/mariadb
        log_success "MariaDB 초기화 완료"
    else
        log_success "MariaDB 데이터베이스가 이미 초기화되어 있습니다"
    fi
    
    # MariaDB 서비스 시작 전 권한 재확인 및 설정
    log_info "MariaDB 권한 및 디렉토리 설정 확인 중..."
    sudo mkdir -p /var/log/mariadb /var/run/mariadb /var/lib/mysql
    sudo chown -R mysql:mysql /var/log/mariadb /var/run/mariadb /var/lib/mysql
    sudo chmod 755 /var/log/mariadb /var/run/mariadb /var/lib/mysql
    log_success "MariaDB 권한 설정 완료"
    
    # MariaDB 기본 설정 파일 생성
    log_info "MariaDB 기본 설정 파일 생성 중..."
    if [[ ! -f /etc/my.cnf ]]; then
        sudo tee /etc/my.cnf > /dev/null << 'EOF'
[mysqld]
datadir=/var/lib/mysql
socket=/var/lib/mysql/mysql.sock
user=mysql
pid-file=/var/run/mariadb/mysqld.pid
log-error=/var/log/mariadb/mariadb.log
port=3306
bind-address=127.0.0.1
default-storage-engine=innodb
character-set-server=utf8mb4
collation-server=utf8mb4_unicode_ci
sql_mode=STRICT_TRANS_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE,ERROR_FOR_DIVISION_BY_ZERO
skip-name-resolve
skip-external-locking
skip-symbolic-links

[mysql]
socket=/var/lib/mysql/mysql.sock

[client]
socket=/var/lib/mysql/mysql.sock
EOF
        log_success "MariaDB 설정 파일 생성 완료"
    else
        log_success "MariaDB 설정 파일이 이미 존재합니다"
    fi
    
    # 설정 파일 권한 확인
    sudo chown root:root /etc/my.cnf
    sudo chmod 644 /etc/my.cnf
    
    # MariaDB 서비스 상태 확인 (기본 mariadb.service 사용)
    if ! sudo systemctl is-active --quiet mariadb; then
        log_warning "MariaDB 서비스가 실행되지 않음, 시작 중..."
        
        # 시작 전 소켓 파일 및 프로세스 정리
        log_info "시작 전 소켓 파일 및 프로세스 정리 중..."
        sudo pkill -f mariadbd 2>/dev/null || true
        sudo pkill -f mysqld 2>/dev/null || true
        sudo rm -f /var/lib/mysql/mysql.sock 2>/dev/null || true
        sudo rm -f /var/run/mariadb/mysqld.pid 2>/dev/null || true
        sudo rm -f /tmp/mysql.sock 2>/dev/null || true
        sleep 2
        
        # MariaDB 서비스 시작
        if sudo systemctl start mariadb; then
            log_success "MariaDB 서비스 시작 완료"
        else
            log_error "MariaDB 서비스 시작 실패"
            
            # 상세한 오류 진단
            log_info "MariaDB 서비스 실패 원인 진단 중..."
            echo "=== MariaDB 서비스 상태 ==="
            sudo systemctl status mariadb.service --no-pager || true
            echo ""
            echo "=== 소켓 파일 상태 ==="
            ls -la /var/lib/mysql/mysql.sock 2>/dev/null || echo "소켓 파일 없음"
            ls -la /var/run/mariadb/mysqld.pid 2>/dev/null || echo "PID 파일 없음"
            echo ""
            echo "=== 프로세스 상태 ==="
            ps aux | grep -i mariadb || echo "MariaDB 프로세스 없음"
            echo ""
            
            # 권한 문제 해결 시도
            log_info "권한 문제 해결 시도 중..."
            sudo chown -R mysql:mysql /var/lib/mysql /var/log/mariadb /var/run/mariadb 2>/dev/null || true
            sudo chmod -R 755 /var/lib/mysql /var/log/mariadb /var/run/mariadb 2>/dev/null || true
            
            # 다시 서비스 시작 시도
            log_info "권한 수정 후 MariaDB 서비스 재시작 시도 중..."
            if sudo systemctl start mariadb; then
                log_success "MariaDB 서비스 재시작 성공"
            else
                log_error "MariaDB 서비스 재시작 실패, 강제 초기화 시도 중..."
                
                # 강제 초기화 시도
                log_info "MariaDB 강제 초기화 시도 중..."
                sudo systemctl stop mariadb 2>/dev/null || true
                sleep 3
                
                # 소켓 파일 및 프로세스 정리
                sudo pkill -f mariadbd || true
                sudo pkill -f mysqld || true
                sudo rm -f /var/lib/mysql/mysql.sock 2>/dev/null || true
                sudo rm -f /var/run/mariadb/mysqld.pid 2>/dev/null || true
                sudo rm -f /tmp/mysql.sock 2>/dev/null || true
                
                # 데이터 디렉토리 백업 및 재생성
                if [[ -d /var/lib/mysql ]]; then
                    sudo mv /var/lib/mysql /var/lib/mysql.backup.$(date +%Y%m%d_%H%M%S) 2>/dev/null || true
                fi
                
                sudo mkdir -p /var/lib/mysql /var/log/mariadb /var/run/mariadb
                sudo chown -R mysql:mysql /var/lib/mysql /var/log/mariadb /var/run/mariadb
                sudo chmod 755 /var/lib/mysql /var/log/mariadb /var/run/mariadb
                
                # MariaDB 재초기화
                sudo mariadb-install-db --user=mysql --datadir=/var/lib/mysql || true
                
                # 소켓 파일 권한 재설정
                sudo chown mysql:mysql /var/lib/mysql /var/log/mariadb /var/run/mariadb
                sudo chmod 755 /var/lib/mysql /var/log/mariadb /var/run/mariadb
                
                # 서비스 재시작
                if sudo systemctl start mariadb; then
                    log_success "MariaDB 강제 초기화 후 시작 성공"
                else
                    log_error "MariaDB 강제 초기화 후 시작 실패, 최종 복구 시도 중..."
                    
                    # 최종 복구: systemd 서비스 재설정
                    log_info "systemd 서비스 재설정 중..."
                    sudo systemctl daemon-reload
                    sudo systemctl reset-failed mariadb.service 2>/dev/null || true
                    
                    # 수동으로 MariaDB 시작 시도
                    log_info "수동으로 MariaDB 시작 시도 중..."
                    if sudo mariadbd --user=mysql --datadir=/var/lib/mysql --pid-file=/var/run/mariadb/mysqld.pid --socket=/var/lib/mysql/mysql.sock --port=3306 --log-error=/var/log/mariadb/mariadb.log &
                    then
                        local mariadb_pid=$!
                        sleep 5
                        
                        if ps -p $mariadb_pid > /dev/null; then
                            log_success "수동 MariaDB 시작 성공 (PID: $mariadb_pid)"
                            # PID 파일 생성
                            echo $mariadb_pid | sudo tee /var/run/mariadb/mysqld.pid > /dev/null
                            sudo chown mysql:mysql /var/run/mariadb/mysqld.pid
                        else
                            log_error "수동 MariaDB 시작 실패"
                            return 1
                        fi
                    else
                        log_error "수동 MariaDB 시작 실패, 수동 설정 필요"
                        log_info "수동 해결 방법:"
                        log_info "1. sudo systemctl status mariadb.service"
                        log_info "2. sudo journalctl -xeu mariadb.service"
                        log_info "3. sudo chown -R mysql:mysql /var/lib/mysql /var/log/mariadb /var/run/mariadb"
                        log_info "4. sudo systemctl start mariadb"
                        return 1
                    fi
                fi
            fi
        fi
        
        # MariaDB 보안 설정 (첫 실행 시에만)
        log_info "MariaDB 보안 설정 확인 중..."
        if mariadb -u root -e "SELECT 1;" 2>/dev/null; then
            log_info "MariaDB 보안 설정이 필요합니다. 자동 설정을 시도합니다..."
            
            # 기본 보안 설정 (비대화형으로)
            mariadb -u root -e "DELETE FROM mysql.user WHERE User='';" 2>/dev/null || true
            mariadb -u root -e "DELETE FROM mysql.user WHERE User='root' AND Host NOT IN ('localhost', '127.0.0.1', '::1');" 2>/dev/null || true
            mariadb -u root -e "DROP DATABASE IF EXISTS test;" 2>/dev/null || true
            mariadb -u root -e "FLUSH PRIVILEGES;" 2>/dev/null || true
            
            log_success "MariaDB 기본 보안 설정 완료"
            log_warning "보안 강화를 위해 'sudo mysql_secure_installation'을 수동으로 실행하는 것을 권장합니다"
        fi
    else
        log_success "MariaDB 서비스가 이미 실행 중입니다"
    fi
    
    # MariaDB 포트 확인
    log_info "MariaDB 포트(3306) 연결 확인 중..."
    if command -v nc >/dev/null 2>&1 && nc -z localhost 3306 2>/dev/null; then
        log_success "MariaDB 포트 3306 연결 정상"
    elif timeout 5 bash -c "</dev/tcp/localhost/3306" 2>/dev/null; then
        log_success "MariaDB 포트 3306 연결 정상"
    else
        log_error "MariaDB 포트 3306 연결 실패"
        return 1
    fi
    
    # MariaDB 데이터베이스 및 사용자 설정
    log_info "MariaDB 데이터베이스 및 사용자 설정 중..."
    
    # root 사용자로 직접 접속 시도 (비밀번호 없이)
    if mariadb -u root -e "SELECT 1;" 2>/dev/null; then
        log_success "MariaDB root 사용자 인증 없이 접속 가능"
        setup_database_and_user
    else
        log_warning "root 사용자 접속 불가, root 사용자 설정 시도 중..."
        
        # 1단계: sudo를 사용하여 root 사용자로 접속
        if sudo mariadb -u root -e "SELECT 1;" 2>/dev/null; then
            log_success "sudo로 root 사용자 접속 가능"
            setup_database_and_user
        else
            log_warning "sudo로도 root 접속 불가, 안전 모드로 설정 시도 중..."
            
            # 2단계: 안전 모드로 MariaDB 시작하여 root 설정
            sudo systemctl stop mariadb 2>/dev/null || true
            sleep 3
            
            # 안전 모드로 MariaDB 시작
            sudo mariadbd --skip-grant-tables --user=mysql &
            local mariadb_pid=$!
            sleep 8
            
            # root 사용자 비밀번호 설정
            if mariadb -u root -e "FLUSH PRIVILEGES;" 2>/dev/null; then
                mariadb -u root -e "ALTER USER 'root'@'localhost' IDENTIFIED BY '';" 2>/dev/null || \
                mariadb -u root -e "UPDATE mysql.user SET plugin='mysql_native_password', authentication_string='' WHERE User='root' AND Host='localhost';" 2>/dev/null
                
                mariadb -u root -e "FLUSH PRIVILEGES;" 2>/dev/null
                log_success "root 사용자 비밀번호 재설정 완료"
                
                # 안전 모드 MariaDB 종료
                sudo kill $mariadb_pid 2>/dev/null || true
                sleep 5
                
                # 정상 모드로 MariaDB 재시작
                if sudo systemctl start mariadb; then
                    sleep 5
                    
                    # root 사용자 접속 테스트
                    if mariadb -u root -e "SELECT 1;" 2>/dev/null; then
                        log_success "root 사용자 접속 성공, 데이터베이스 설정 진행"
                        setup_database_and_user
                    else
                        log_error "root 사용자 접속 실패"
                        return 1
                    fi
                else
                    log_error "MariaDB 서비스 재시작 실패"
                    return 1
                fi
            else
                log_error "root 사용자 설정 실패"
                sudo kill $mariadb_pid 2>/dev/null || true
                sudo systemctl start mariadb
                return 1
            fi
        fi
    fi
    
    # Django 설치 상태 확인
    log_info "Django 설치 상태 확인 중..."
    if ! python -c "import django; print('Django 버전:', django.get_version())" 2>/dev/null; then
        log_error "Django가 설치되지 않았습니다. 의존성 설치를 먼저 완료하세요."
        return 1
    fi
    
    # 환경변수 설정
    export DB_NAME DB_USER DB_PASSWORD DB_HOST DB_PORT

    # MariaDB 연결 확인
    log_info "MariaDB 연결 확인 중..."
    log_info "연결 정보: ${DB_HOST}:${DB_PORT}/${DB_NAME} (사용자: ${DB_USER})"
    
    # 1단계: MariaDB 서비스 상태 확인
    if ! sudo systemctl is-active --quiet mariadb; then
        log_error "MariaDB 서비스가 실행되지 않음, 서비스 시작 시도 중..."
        
        if sudo systemctl start mariadb; then
            log_success "MariaDB 서비스 시작 성공"
            sleep 3  # 서비스 안정화 대기
        else
            log_error "MariaDB 서비스 시작 실패, 수동 복구 필요"
            log_info "수동 복구 방법:"
            log_info "1. sudo systemctl start mariadb"
            log_info "2. sudo systemctl status mariadb"
            return 1
        fi
    fi
    
    # 2단계: 데이터베이스 존재 여부 확인 및 생성
    log_info "데이터베이스 존재 여부 확인 중..."
    if sudo mariadb -u root -e "USE ${DB_NAME};" 2>/dev/null; then
        log_success "데이터베이스 ${DB_NAME} 존재함"
    else
        log_warning "데이터베이스 ${DB_NAME}가 없음, 생성 중..."
        if sudo mariadb -u root -e "CREATE DATABASE ${DB_NAME} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" 2>/dev/null; then
            log_success "데이터베이스 ${DB_NAME} 생성 완료"
        else
            log_error "데이터베이스 생성 실패"
            return 1
        fi
    fi
    
    # 3단계: 기본 연결 테스트
    if mariadb -h "${DB_HOST}" -u "${DB_USER}" -p"${DB_PASSWORD}" -D "${DB_NAME}" -e "SELECT 1;" >/dev/null 2>&1; then
        log_success "MariaDB 연결 정상"
    else
        log_warning "kbo_user 연결 실패, root 사용자로 복구 시도 중..."
        
        # root 사용자로 연결 시도 (복구)
        if mariadb -u root -e "USE ${DB_NAME}; SELECT 1;" 2>/dev/null; then
            log_success "root 사용자로 연결 성공, kbo_user 권한 재설정 중..."
            
            # kbo_user 권한 재설정
            mariadb -u root -e "GRANT ALL PRIVILEGES ON ${DB_NAME}.* TO 'kbo_user'@'localhost';" 2>/dev/null
            mariadb -u root -e "FLUSH PRIVILEGES;" 2>/dev/null
            
            # 다시 kbo_user로 연결 시도
            if mariadb -h "${DB_HOST}" -u "${DB_USER}" -p"${DB_PASSWORD}" -D "${DB_NAME}" -e "SELECT 1;" >/dev/null 2>&1; then
                log_success "kbo_user 연결 복구 성공"
            else
                log_warning "kbo_user 연결 복구 실패, root 사용자로 진행"
                export DB_USER="root"
                export DB_PASSWORD=""
            fi
        else
            log_error "root 사용자 연결도 실패, MariaDB 서비스 문제"
            return 1
        fi
    fi
    
    # 마이그레이션 전 최종 데이터베이스 연결 확인
    log_info "마이그레이션 전 최종 데이터베이스 연결 확인 중..."
    if sudo mariadb -u root -e "USE ${DB_NAME}; SELECT 1;" 2>/dev/null; then
        log_success "데이터베이스 연결 확인 완료"
    else
        log_error "데이터베이스 연결 실패, 마이그레이션을 진행할 수 없습니다"
        return 1
    fi
    
    # 마이그레이션 파일 정리
    log_info "마이그레이션 파일 정리 중..."
    if [[ -f "kbo/migrations/0002_add_player_image_url.py" ]]; then
        log_warning "문제가 되는 마이그레이션 파일 제거 중..."
        rm -f kbo/migrations/0002_add_player_image_url.py
        log_success "마이그레이션 파일 정리 완료"
    fi
    
    # 새로운 마이그레이션 생성
    log_info "새로운 마이그레이션 생성 중..."
    python manage.py makemigrations kbo || {
        log_warning "마이그레이션 생성 실패, 빈 마이그레이션으로 시작..."
        python manage.py makemigrations kbo --empty || true
    }
    
    # 마이그레이션 실행
    log_info "MariaDB 마이그레이션 실행 중..."
    if python manage.py migrate; then
        log_success "마이그레이션 성공"
    else
        log_warning "마이그레이션 실패, Django 설정 확인 필요"
        
        # Django 설정에서 데이터베이스 연결 확인
        log_info "Django 데이터베이스 설정 확인 중..."
        if python manage.py check --database default; then
            log_success "Django 설정 정상"
        else
            log_error "Django 설정에 문제가 있습니다"
            
            # 데이터베이스 연결 문제 해결 시도
            log_info "데이터베이스 연결 문제 해결 시도 중..."
            setup_database_and_user
            
            # 마이그레이션 재시도
            log_info "마이그레이션 재시도 중..."
            if python manage.py migrate; then
                log_success "마이그레이션 재시도 성공"
            else
                log_error "마이그레이션 재시도 실패"
            fi
        fi
    fi
    
    # 팀 데이터 초기화 (없으면 생성)
    log_info "팀 데이터 초기화 중..."
    python - <<'PY'
import os
import django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "kbo_crawler.settings")
django.setup()
from kbo.models import Team

defaults = [
    ("KIA 타이거즈", "KIA"),
    ("LG 트윈스", "LG"),
    ("SSG 랜더스", "SSG"),
    ("롯데 자이언츠", "LT"),
    ("키움 히어로즈", "WO"),
    ("두산 베어스", "DS"),
    ("한화 이글스", "HH"),
    ("삼성 라이온즈", "SS"),
    ("KT 위즈", "KT"),
    ("NC 다이노스", "NC"),
]

created = 0
for name, code in defaults:
    obj, was_created = Team.objects.get_or_create(code=code, defaults={"name": name})
    created += int(was_created)
print(f"[INFO] 팀 초기화: 생성 {created}건, 총 {Team.objects.count()}건")
PY
    
    log_success "데이터베이스 설정 완료"
}

# KBO 데이터 크롤링

run_kbo_crawling() {
    log_step "KBO 데이터 크롤링"
    
    cleanup_chrome
    check_memory
    
    cd "${CODE_DIR}"
    source venv/bin/activate
    
    # 환경변수 설정
    export DB_NAME DB_USER DB_PASSWORD DB_HOST DB_PORT
    
    # 크롤링 전 환경 확인
    log_info "크롤링 환경 확인 중..."
    echo "Python 버전: $(python --version)"
    echo "현재 디렉토리: $(pwd)"
    echo "가상환경: $VIRTUAL_ENV"
    
    # 팀 정보 정의
    local teams=("KIA" "LG" "SSG" "LT" "WO" "DS" "HH" "SS" "KT" "NC")
    local team_names=("KIA 타이거즈" "LG 트윈스" "SSG 랜더스" "롯데 자이언츠" "키움 히어로즈" "두산 베어스" "한화 이글스" "삼성 라이온즈" "KT 위즈" "NC 다이노스")
    
    # 팀별 순차 크롤링
    for i in "${!teams[@]}"; do
        local team_code="${teams[$i]}"
        local team_name="${team_names[$i]}"
        
        log_info "=== ${team_name} 크롤링 시작 ==="
        
        # 1차: 기본 크롤링 시도
        if python manage.py fetch_kbo2 --only "${team_code}" --sleep 1.0; then
            log_success "${team_name} 크롤링 성공"
        else
            log_warning "${team_name} 기본 크롤링 실패, 대체 방법 시도 중..."
            
            # 2차: 대체 크롤링 시도 (더 긴 대기 시간)
            if python manage.py fetch_kbo2 --only "${team_code}" --sleep 3.0 --retry 2; then
                log_success "${team_name} 대체 크롤링 성공"
            else
                log_warning "${team_name} 대체 크롤링도 실패, 수동 크롤링 시도 중..."
                
                # 3차: 수동 크롤링 시도 (더 상세한 옵션)
                if python manage.py fetch_kbo2 --only "${team_code}" --sleep 5.0 --retry 3 --verbose; then
                    log_success "${team_name} 수동 크롤링 성공"
                else
                    log_error "${team_name} 모든 크롤링 방법 실패"
                fi
            fi
        fi
        
        # 크롤링 후 정리
        cleanup_chrome
        check_memory
        
        # 결과 확인
        local player_count=$(python manage.py shell -c "from kbo.models import Player, Team; print(Player.objects.filter(team__code='${team_code}').count())" 2>/dev/null)
        log_info "${team_name} 선수 수: ${player_count:-0}명"
        
        log_success "${team_name} 크롤링 완료"
        echo ""
        
        # 다음 팀 전 대기
        if [[ $i -lt $((${#teams[@]} - 1)) ]]; then
            log_info "다음 팀 크롤링 전 3초 대기..."
            sleep 3
        fi
    done
    
    log_success "모든 팀 순차 크롤링 완료!"
    

}

# Django 서버 관리

test_django_features() {
    log_step "Django 기능 테스트"
    
    cd "${CODE_DIR}"
    source venv/bin/activate
    
    # 환경변수 설정
    export DB_NAME DB_USER DB_PASSWORD DB_HOST DB_PORT DJANGO_SETTINGS_MODULE=kbo_crawler.settings DEBUG=False
    
    # 서버 시작
    log_info "Django 프로덕션 서버 시작 중..."
    gunicorn --bind 0.0.0.0:8000 --workers 2 --timeout 60 kbo_crawler.wsgi:application &
    local django_pid=$!
    sleep 20
    
    # 기본 페이지 테스트
    log_info "기본 페이지 테스트 중..."
    if curl -s -o /dev/null -w "%{http_code}" http://localhost:8000/players | grep -q "200"; then
        log_success "메인 페이지 정상 (/players)"
    else
        log_warning "메인 페이지 응답 없음 (서버 시작 중일 수 있음)"
    fi
    
    # 서버 종료
    log_info "Django 서버 종료 중..."
    kill $django_pid 2>/dev/null || true
    sleep 5
    
    log_success "Django 기능 테스트 완료!"
}

# systemd 서비스 관리

create_systemd_service() {
    log_step "systemd 서비스 생성"
    
    cd "${CODE_DIR}"
    
    # 서비스 파일 생성
    log_info "kbo-django.service 파일 생성 중..."
    sudo tee /etc/systemd/system/kbo-django.service << EOF
[Unit]
Description=KBO Django Application
Documentation=https://github.com/your-repo/kbo-django
After=network.target
Wants=network.target

[Service]
Type=notify
User=ec2-user
Group=ec2-user
WorkingDirectory=${CODE_DIR}
Environment=DB_NAME=${DB_NAME}
Environment=DB_USER=${DB_USER}
Environment=DB_PASSWORD=${DB_PASSWORD}
Environment=DB_HOST=${DB_HOST}
Environment=DB_PORT=${DB_PORT}
Environment=DJANGO_SETTINGS_MODULE=kbo_crawler.settings
Environment=DEBUG=False
Environment=ALLOWED_HOSTS="*"
Environment=PYTHONPATH=${CODE_DIR}
ExecStart=${CODE_DIR}/venv/bin/gunicorn \\
    --bind 0.0.0.0:8000 \\
    --workers 4 \\
    --worker-class sync \\
    --worker-connections 1000 \\
    --max-requests 1000 \\
    --max-requests-jitter 100 \\
    --timeout 120 \\
    --keep-alive 2 \\
    --preload \\
    --access-logfile /var/log/kbo-django/access.log \\
    --error-logfile /var/log/kbo-django/error.log \\
    --log-level info \\
    kbo_crawler.wsgi:application
ExecReload=/bin/kill -s HUP \$MAINPID
Restart=always
RestartSec=5
StartLimitInterval=0
StartLimitBurst=0

[Install]
WantedBy=multi-user.target
EOF
    
    # 로그 디렉토리 생성
    log_info "로그 디렉토리 생성 중..."
    sudo mkdir -p /var/log/kbo-django
    sudo chown ec2-user:ec2-user /var/log/kbo-django
    sudo chmod 755 /var/log/kbo-django
    
    # 서비스 활성화
    log_info "systemd 서비스 활성화 중..."
    sudo systemctl daemon-reload
    sudo systemctl enable kbo-django
    
    if sudo systemctl is-enabled kbo-django; then
        log_success "✅ kbo-django 서비스 활성화 완료"
    else
        log_warning "⚠️  kbo-django 서비스 활성화 실패"
    fi
    
    log_success "systemd 서비스 생성 완료!"
}

# 데이터베이스 상태 확인

check_database_status() {
    log_step "데이터베이스 상태 확인"
    
    cd "${CODE_DIR}"
    source venv/bin/activate
    
    # 환경변수 설정
    export DB_NAME DB_USER DB_PASSWORD DB_HOST DB_PORT
    
    # MariaDB 연결 테스트
    log_info "MariaDB 연결 테스트 중..."
    if mariadb -h "${DB_HOST}" -u "${DB_USER}" -p"${DB_PASSWORD}" -D "${DB_NAME}" -e "SELECT VERSION();" >/dev/null 2>&1; then
        log_success "MariaDB 연결 정상"
    else
        log_error "MariaDB 연결 실패"
        return 1
    fi
    
    # 데이터 통계 확인
    local team_count=$(mariadb -h "${DB_HOST}" -u "${DB_USER}" -p"${DB_PASSWORD}" -D "${DB_NAME}" -s -e "SELECT COUNT(*) FROM kbo_team;" 2>/dev/null | tr -d ' ')
    local player_count=$(mariadb -h "${DB_HOST}" -u "${DB_USER}" -p"${DB_PASSWORD}" -D "${DB_NAME}" -s -e "SELECT COUNT(*) FROM kbo_player;" 2>/dev/null | tr -d ' ')
    local manager_count=$(mariadb -h "${DB_HOST}" -u "${DB_USER}" -p"${DB_PASSWORD}" -D "${DB_NAME}" -s -e "SELECT COUNT(*) FROM kbo_manager;" 2>/dev/null | tr -d ' ')
    
    log_info "총 팀 수: ${team_count:-0}개"
    log_info "총 선수 수: ${player_count:-0}명"
    log_info "총 감독 수: ${manager_count:-0}명"
    
    # 포지션별 선수 분포
    log_info "포지션별 선수 분포:"
    mariadb -h "${DB_HOST}" -u "${DB_USER}" -p"${DB_PASSWORD}" -D "${DB_NAME}" -e "
SELECT position, COUNT(*) as count 
FROM kbo_player 
WHERE position != '' 
GROUP BY position 
ORDER BY count DESC 
LIMIT 10;
" 2>/dev/null || log_warning "포지션 데이터 없음"
    
    echo ""
}

# =============================================================================
# 메인 실행 함수
# 메인 실행 함수

main() {
    log_step "KBO 정보 서비스 자동 설치 및 크롤링 시작"
    echo "스크립트 버전: ${SCRIPT_VERSION}"
    echo "시작 시간: $(date)"
    echo "작업 디렉토리: ${CODE_DIR}"
    echo ""
    echo "[DB] MariaDB 연결 정보:"
    echo "   호스트: ${DB_HOST}"
    echo "   포트: ${DB_PORT}"
    echo "   데이터베이스: ${DB_NAME}"
    echo "   사용자: ${DB_USER}"
    echo ""

    # 환경변수 로드
    load_environment
    
    # 1) 시스템 준비
    log_step "1. 시스템 준비"
    install_system_packages
    
    # 2) Python 설치
    log_step "2. Python 설치"
    # Python 3.13 설치 확인
    if command -v python3.13 >/dev/null 2>&1; then
        log_success "Python 3.13 사용 가능"
        log_info "Python 3.13 버전: $(python3.13 --version)"
    else
        log_error "Python 3.13이 설치되지 않았습니다"
        return 1
    fi
    
    # 3) Chrome 설치
    log_step "3. Chrome 설치"
    install_chrome
    
    # 4) Chromedriver 설치
    log_step "4. Chromedriver 설치"
    install_chromedriver
    
    # 5) 가상환경 및 의존성 설치
    log_step "5. 가상환경 및 의존성 설치"
    setup_virtual_environment
    
    # 6) 데이터베이스 설정
    log_step "6. 데이터베이스 설정"
    setup_database
    
    # 7) KBO 데이터 크롤링
    log_step "7. KBO 데이터 크롤링"
    run_kbo_crawling
    
    # 8) 데이터베이스 상태 확인
    log_step "8. 크롤링 결과 확인"
    check_database_status
    
    # 9) Django 기능 테스트
    log_step "9. Django 기능 테스트"
    test_django_features
    
    # 10) systemd 서비스 생성
    log_step "10. systemd 서비스 생성"
    create_systemd_service
    
    # 11) 완료 요약
    log_step "설치 및 크롤링 완료!"
    echo "[TIME] 완료 시간: $(date)"
    echo "[CMD] 실행 명령어:"
    echo "   # systemd 서비스로 실행"
    echo "   sudo systemctl start kbo-django"
    echo "   sudo systemctl status kbo-django"
    echo ""
    echo "   # systemd 서비스 관리"
    echo "   sudo systemctl start kbo-django      # 서비스 시작"
    echo "   sudo systemctl stop kbo-django       # 서비스 중지"
    echo "   sudo systemctl restart kbo-django    # 서비스 재시작"
    echo "   sudo systemctl status kbo-django     # 서비스 상태 확인"
    echo "   sudo journalctl -u kbo-django -f     # 실시간 로그 확인"
    echo ""
    echo "   # 수동으로 실행하려면"
    echo "   cd ${CODE_DIR}"
    echo "   source venv/bin/activate"
    echo "   export DB_NAME=${DB_NAME}"
    echo "   export DB_USER=${DB_USER}"
    echo "   export DB_PASSWORD=${DB_PASSWORD}"
    echo "   export DB_HOST=${DB_HOST}"
    echo "   export DB_PORT=${DB_PORT}"
    echo "   gunicorn --bind 0.0.0.0:8000 --workers 4 kbo_crawler.wsgi:application"
    echo ""
    echo "[TIP] 크롤링 중 문제가 발생하면 'pkill -f chrome'으로 Chrome 프로세스를 정리하세요."
    echo "[TIP] Django 서버는 systemd 서비스로 등록되어 자동 시작/재시작됩니다."
    echo "[TIP] Django는 8000번 포트에서 실행됩니다."
    echo "[TIP] 외부에서 접속할 때는 EC2의 공인 IP:8000으로 접속하면 됩니다."
    echo "[TIP] 로그는 /var/log/kbo-django/ 디렉토리와 journalctl에서 확인할 수 있습니다."
    echo "[TIP] 서버 재부팅 시에도 자동으로 Django가 시작됩니다."
    echo ""
    echo "[DB] MariaDB 연결 정보 요약:"
    echo "   호스트: ${DB_HOST}"
    echo "   포트: ${DB_PORT}"
    echo "   데이터베이스: ${DB_NAME}"
    echo "   사용자: ${DB_USER}"
    echo ""
    log_success "모든 작업이 성공적으로 완료되었습니다!"
}

# 스크립트 실행
main "$@"
