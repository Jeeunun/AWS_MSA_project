from django.core.management.base import BaseCommand
from django.conf import settings
from kbo.models import Player, Team
# 온프레미스 환경에서는 AWS S3를 사용하지 않음
# import boto3
import os
from pathlib import Path
# from botocore.exceptions import ClientError

class Command(BaseCommand):
    help = 'S3에 선수 이미지 업로드'

    def add_arguments(self, parser):
        parser.add_argument(
            '--local-path',
            type=str,
            help='로컬 이미지 폴더 경로',
        )
        parser.add_argument(
            '--team',
            type=str,
            help='특정 팀만 업로드 (팀 코드)',
        )

    def handle(self, *args, **options):
        # S3 클라이언트 생성
        s3_client = boto3.client(
            's3',
            aws_access_key_id=os.environ.get('AWS_ACCESS_KEY_ID'),
            aws_secret_access_key=os.environ.get('AWS_SECRET_ACCESS_KEY'),
            region_name=os.environ.get('AWS_DEFAULT_REGION', 'ap-northeast-2')
        )
        
        bucket_name = os.environ.get('AWS_S3_BUCKET', '')
        local_path = options['local_path'] or 'player_images'
        team_filter = options['team']
        
        self.stdout.write(f'S3 이미지 업로드 시작: {bucket_name}')
        
        # 팀별로 이미지 업로드
        teams = Team.objects.all()
        if team_filter:
            teams = teams.filter(code=team_filter)
        
        # 업로드한 객체를 공개로 만들지 여부 (기본: 공개)
        public_read = os.environ.get('AWS_S3_PUBLIC_READ', 'true').lower() in ['1', 'true', 'yes']

        for team in teams:
            self.stdout.write(f'\n팀: {team.name} ({team.code})')
            
            # 팀 폴더 경로
            team_local_path = Path(local_path) / team.code
            if not team_local_path.exists():
                self.stdout.write(f'  팀 폴더가 없습니다: {team_local_path}')
                continue
            
            # 팀의 모든 선수
            players = team.players.all()
            
            for player in players:
                # 이미지 파일 찾기
                image_extensions = ['.jpg', '.jpeg', '.png']
                player_image = None
                
                for ext in image_extensions:
                    # 여러 가능한 파일명 시도
                    possible_names = [
                        f"{player.name}{ext}",
                        f"{player.name.replace(' ', '_')}{ext}",
                        f"{player.name.replace(' ', '')}{ext}",
                    ]
                    
                    for name in possible_names:
                        image_path = team_local_path / name
                        if image_path.exists():
                            player_image = image_path
                            break
                    
                    if player_image:
                        break
                
                if player_image:
                    # S3에 업로드
                    s3_key = f"players/{team.code}/{player_image.name}"
                    
                    try:
                        extra_args = {
                            'ContentType': 'image/jpeg' if player_image.suffix in ['.jpg', '.jpeg'] else 'image/png',
                            'CacheControl': 'public, max-age=31536000'
                        }
                        if public_read:
                            # 버킷이 Object Ownership: Bucket owner enforced 인 경우 무시될 수 있음
                            # 이때는 버킷 정책으로 공개 권한을 부여해야 함
                            extra_args['ACL'] = 'public-read'

                        s3_client.upload_file(
                            str(player_image),
                            bucket_name,
                            s3_key,
                            ExtraArgs=extra_args
                        )
                        
                        # 데이터베이스 업데이트
                        player.image_url = f"https://{bucket_name}.s3.ap-northeast-2.amazonaws.com/{s3_key}"
                        player.save()
                        
                        self.stdout.write(f'  ✅ {player.name}: {s3_key}')
                        
                    except ClientError as e:
                        self.stdout.write(f'  ❌ {player.name}: {e}')
                else:
                    self.stdout.write(f'  ⚠️  {player.name}: 이미지 파일 없음')
        
        self.stdout.write('\n업로드 완료!')

