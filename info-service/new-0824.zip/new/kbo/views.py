from django.shortcuts import render, get_object_or_404
from django.core.paginator import Paginator
from django.http import HttpResponse, JsonResponse
from django.db.models import Count, Avg, Min, Max, Case, When, IntegerField
from django.db.models.functions import ExtractYear, Length
from datetime import date, datetime
from typing import Any, Dict, List
from .models import Team, Player
from .utils import (
    calculate_player_age, calculate_team_physical_stats, 
    calculate_team_age_stats, get_position_counts, 
    calculate_position_percentages, CURRENT_YEAR, CURRENT_DATE
)
import csv
import re
# AWS S3 관련 import 주석 처리 (온프레미스 환경)
# import boto3
# from botocore.exceptions import ClientError
import os
import json

def get_s3_player_image_url(team_code: str, player_name: str, player_number: str | None = None) -> str | None:
    """
    S3에서 선수 이미지 URL을 검색해 반환합니다.
    실제 업로드 구조: players/ 디렉터리 바로 아래에 파일이 위치하며, 파일명은
    "{팀코드}_{등번호}_{이름}_...jpg" 형태입니다. 예) players/DS_00_김재호_내야수.jpg
    """
    try:
        # 온프레미스 환경에서는 S3를 사용하지 않음
        return None
        bucket_name = os.environ.get('AWS_S3_BUCKET', '')
        if not bucket_name:
            print('⚠️  AWS_S3_BUCKET 환경변수가 설정되지 않았습니다.')
            return None

        base_prefix = f"players/{team_code}_"

        def name_candidates(name: str):
            return [name, name.replace(' ', ''), name.replace(' ', '_')]

        # 1) 등번호가 있으면 번호 프리픽스를 우선 시도 (0패딩/무패딩 모두)
        if player_number and player_number.isdigit():
            raw = str(int(player_number))  # 무패딩
            padded2 = raw.zfill(2)
            padded3 = raw.zfill(3)
            for num in [raw, padded2, padded3]:
                try:
                    prefix = f"{base_prefix}{num}_"
                    resp = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=prefix, MaxKeys=100)
                    for obj in resp.get('Contents', []):
                        key = obj['Key']
                        if any(cand in key for cand in name_candidates(player_name)):
                            return f"https://{bucket_name}.s3.ap-northeast-2.amazonaws.com/{key}"
                except Exception as e:
                    # 다음 케이스 시도
                    print(f"⚠️  번호 {num} 프리픽스 검색 실패: {e}")

        # 2) 팀코드만으로 브로드 검색 후 이름 포함 파일 찾기
        try:
            resp = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=base_prefix, MaxKeys=1000)
            for obj in resp.get('Contents', []):
                key = obj['Key']
                if any(cand in key for cand in name_candidates(player_name)):
                    return f"https://{bucket_name}.s3.ap-northeast-2.amazonaws.com/{key}"
        except Exception as e:
            print(f"⚠️  팀코드 기반 브로드 검색 실패: {e}")

        print(f"⚠️  S3에서 이미지 미발견: team={team_code}, name={player_name}, number={player_number}")
        return None
    except NoCredentialsError:
        print("❌ AWS 인증 정보가 없습니다")
        return None
    except ClientError as e:
        print(f"❌ S3 클라이언트 오류: {e}")
        return None
    except Exception as e:
        print(f"❌ 예상치 못한 오류: {e}")
        return None

def team_list(request):
    teams = (
        Team.objects.select_related('manager')
        .annotate(player_count=Count('players'))
        .order_by('name')
    )
    return render(request, 'kbo/team_list.html', {'teams': teams})


def team_detail(request, code: str):
    team = get_object_or_404(Team, code=code)

    # Filters
    pos = request.GET.get('pos', '').strip()
    sort = request.GET.get('sort', 'num').strip()  # num | name | pos
    page = int(request.GET.get('page', '1') or 1)
    per_page = int(request.GET.get('per', '50') or 50)

    qs = team.players.all()
    if pos:
        qs = qs.filter(position__icontains=pos)

    filtered_count = qs.count()

    # numeric-friendly ordering for back_number
    qs = qs.annotate(
        bn_len=Length('back_number'),
        bn_empty=Case(
            When(back_number__isnull=True, then=1),
            When(back_number='', then=1),
            default=0,
            output_field=IntegerField(),
        ),
    )

    if sort == 'name':
        qs = qs.order_by('name')
    elif sort == 'pos':
        qs = qs.order_by('position', 'bn_empty', 'bn_len', 'back_number')
    else:  # 'num'
        qs = qs.order_by('bn_empty', 'bn_len', 'back_number', 'name')

    paginator = Paginator(qs, per_page)
    page_obj = paginator.get_page(page)

    # JSON export for AJAX requests
    if request.GET.get('format') == 'json':
        players_data = []
        for p in qs:
                    players_data.append({
            'id': p.id,
            'name': p.name,
            'back_number': p.back_number,
            'position': p.position,
            'height': p.height,
            'weight': p.weight,
            'birthdate': p.birthdate.isoformat() if p.birthdate else None,
            'bats_throws': p.bats_throws,
            'bats': p.bats,
            'throws': p.throws,
        })
        return JsonResponse({
            'team_name': team.name,
            'team_code': team.code,
            'players': players_data,
            'total_count': len(players_data)
        })
    
    # CSV export (kept for internal use; links may be hidden)
    if request.GET.get('format') == 'csv':
        response = HttpResponse(content_type='text/csv; charset=utf-8')
        response['Content-Disposition'] = f'attachment; filename="{team.code}_players.csv"'
        writer = csv.writer(response)
        writer.writerow(['팀', '등번호', '이름', '포지션', '키', '몸무게', '생년월일', '투타정보'])
        for p in qs:
            writer.writerow([
                team.name,
                p.back_number,
                p.name,
                p.position,
                p.height,
                p.weight,
                p.birthdate.isoformat() if p.birthdate else '',
                p.bats_throws or (f"{p.throws}투{p.bats}타" if (p.throws or p.bats) else ''),
            ])
        return response

    positions = (
        team.players.exclude(position='').values_list('position', flat=True).distinct().order_by('position')
    )
    
    # 포지션별 선수 수 계산 (리스트 형태로)
    position_stats = []
    for pos_name in positions:
        position_stats.append({
            'name': pos_name,
            'count': team.players.filter(position=pos_name).count()
        })

    # 팀별 선수 수 계산 (사이드바용)
    all_teams = Team.objects.all()
    team_player_counts = {}
    for t in all_teams:
        team_player_counts[t.code] = t.players.count()
    
    return render(
        request,
        'kbo/team_detail.html',
        {
            'team': team,
            'players': page_obj,
            'positions': positions,
            'position_stats': position_stats,
            'pos': pos,
            'sort': sort,
            'per_page': per_page,
            'total_players': filtered_count,
            'teams': all_teams,  # 다른 팀 목록
            'team_player_counts': team_player_counts,  # 팀별 선수 수
        }
    )


def stats_analysis(request):
    """데이터 분석 페이지"""
    # 전체 선수 수
    total_players = Player.objects.count()
    
    # 팀별 선수 수 및 나이 계산
    team_stats = []
    for team in Team.objects.all():
        players = team.players.all()
        player_count = players.count()
        
        # 유틸리티 함수를 사용하여 나이 통계 계산
        age_stats = calculate_team_age_stats(players)
        
        team_stats.append({
            'name': team.name,
            'code': team.code,
            'player_count': player_count,
            'avg_age': age_stats['avg_age'],
            'min_age': age_stats['min_age'],
            'max_age': age_stats['max_age']
        })
    
    # 선수 수 기준으로 정렬
    team_stats.sort(key=lambda x: x['player_count'], reverse=True)
    
    # 포지션별 선수 분포
    position_stats = Player.objects.exclude(position='').values('position').annotate(
        count=Count('id')
    ).order_by('-count')
    
    # 연령대별 분포
    age_groups = {
        '20대 이하': Player.objects.filter(birthdate__year__gte=CURRENT_YEAR-20).count(),
        '21-25세': Player.objects.filter(birthdate__year__range=(CURRENT_YEAR-25, CURRENT_YEAR-21)).count(),
        '26-30세': Player.objects.filter(birthdate__year__range=(CURRENT_YEAR-30, CURRENT_YEAR-26)).count(),
        '31-35세': Player.objects.filter(birthdate__year__range=(CURRENT_YEAR-35, CURRENT_YEAR-31)).count(),
        '36세 이상': Player.objects.filter(birthdate__year__lt=CURRENT_YEAR-35).count(),
    }
    
    # 팀별 포지션 분포
    team_position_stats = {}
    for team in Team.objects.all():
        positions = team.players.exclude(position='').values('position').annotate(
            count=Count('id')
        ).order_by('-count')
        team_position_stats[team.code] = {
            'name': team.name,
            'positions': list(positions)
        }
    
    return render(request, 'kbo/stats_analysis.html', {
        'total_players': total_players,
        'teams': Team.objects.all(),  # 팀 버튼용 teams 변수 추가
        'team_stats': team_stats,
        'position_stats': position_stats,
        'age_groups': age_groups,
        'team_position_stats': team_position_stats,
    })

def search_advanced(request):
    """고급 검색 페이지"""
    q = request.GET.get('q', '').strip()
    team_code = request.GET.get('team', '').strip()
    pos = request.GET.get('pos', '').strip()
    age_min = request.GET.get('age_min', '').strip()
    age_max = request.GET.get('age_max', '').strip()
    sort = request.GET.get('sort', 'name').strip()
    page = int(request.GET.get('page', '1') or 1)
    per_page = int(request.GET.get('per', '50') or 50)

    qs = Player.objects.select_related('team')
    
    # 기본 검색
    if q:
        qs = qs.filter(name__icontains=q)
    if team_code:
        qs = qs.filter(team__code=team_code)
    if pos:
        qs = qs.filter(position__icontains=pos)
    
    # 연령 검색
    if age_min:
        try:
            min_year = CURRENT_YEAR - int(age_min)
            qs = qs.filter(birthdate__year__lte=min_year)
        except ValueError:
            pass
    if age_max:
        try:
            max_year = CURRENT_YEAR - int(age_max)
            qs = qs.filter(birthdate__year__gte=max_year)
        except ValueError:
            pass

    # 정렬
    if sort == 'age':
        qs = qs.order_by('birthdate')
    elif sort == 'team':
        qs = qs.order_by('team__name', 'name')
    elif sort == 'position':
        qs = qs.order_by('position', 'team__name', 'name')
    else:  # name
        qs = qs.order_by('name', 'team__name')

    paginator = Paginator(qs, per_page)
    page_obj = paginator.get_page(page)

    teams = Team.objects.order_by('name').values('name', 'code')
    positions = Player.objects.exclude(position='').values_list('position', flat=True).distinct().order_by('position')

    return render(request, 'kbo/search_advanced.html', {
        'teams': teams,
        'players': page_obj,
        'total_results': qs.count(),
        'page_obj': page_obj,
        'q': q,
        'team_code': team_code,
        'pos': pos,
        'age_min': age_min,
        'age_max': age_max,
        'sort': sort,
        'per_page': per_page,
        'positions': positions,
    })

def team_position_stats_api(request):
    """팀별 포지션 통계를 JSON으로 제공하는 API"""
    try:
        teams_data = []
        
        for team in Team.objects.all():
            # 팀의 선수들 가져오기
            players = team.players.all()
            total_players = players.count()
            
            if total_players == 0:
                continue
            
            # 유틸리티 함수를 사용하여 포지션별 선수 수 계산
            position_counts = get_position_counts(players)
            
            # 유틸리티 함수를 사용하여 퍼센트 계산
            position_percentages = calculate_position_percentages(position_counts, total_players)
            
            # 유틸리티 함수를 사용하여 연령별 분포 계산
            age_stats = calculate_team_age_stats(players)
            age_percentages = age_stats['age_percentages']
            
            teams_data.append({
                'code': team.code,
                'name': team.name,
                'total_players': total_players,
                'position_percentages': position_percentages,
                'age_percentages': age_percentages
            })
        
        return JsonResponse({
            'success': True,
            'teams': teams_data,
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=500)

def team_comparison(request):
    """팀 구성 비교 페이지"""
    team_code1 = request.GET.get('team1', '').strip()
    team_code2 = request.GET.get('team2', '').strip()
    
    teams = Team.objects.order_by('name')
    
    if team_code1 and team_code2:
        team1 = get_object_or_404(Team, code=team_code1)
        team2 = get_object_or_404(Team, code=team_code2)
        
        # 팀별 기본 통계
        # 유틸리티 함수를 사용하여 나이 통계 계산
        team1_age_stats = calculate_team_age_stats(team1.players.all())
        team2_age_stats = calculate_team_age_stats(team2.players.all())
        
        team1_avg_age = team1_age_stats['avg_age']
        team2_avg_age = team2_age_stats['avg_age']
        
        # 팀1 포지션별 선수 수 계산
        team1_position_counts = get_position_counts(team1.players.all())
        team1.pitcher_count = team1_position_counts.get('pitcher', 0)
        team1.infielder_count = team1_position_counts.get('infielder', 0)
        team1.outfielder_count = team1_position_counts.get('outfielder', 0)
        team1.catcher_count = team1_position_counts.get('catcher', 0)
        team1.player_count = team1.players.count()  # 총 선수 수 추가
        
        # 팀2 포지션별 선수 수 계산
        team2_position_counts = get_position_counts(team2.players.all())
        team2.pitcher_count = team2_position_counts.get('pitcher', 0)
        team2.infielder_count = team2_position_counts.get('infielder', 0)
        team2.outfielder_count = team2_position_counts.get('outfielder', 0)
        team2.catcher_count = team2_position_counts.get('catcher', 0)
        team2.player_count = team2.players.count()  # 총 선수 수 추가
        
        # 팀1 키/몸무게 평균 계산
        team1_physical_stats = calculate_team_physical_stats(team1.players.all())
        team1_avg_height = team1_physical_stats['avg_height']
        team1_avg_weight = team1_physical_stats['avg_weight']
        
        # 팀2 키/몸무게 평균 계산
        team2_physical_stats = calculate_team_physical_stats(team2.players.all())
        team2_avg_height = team2_physical_stats['avg_height']
        team2_avg_weight = team2_physical_stats['avg_weight']
        
        team1_stats = {
            'total_players': team1.players.count(),
            'positions': team1.players.exclude(position='').values('position').annotate(count=Count('id')),
            'avg_age': team1_avg_age,
            'avg_height': team1_avg_height,
            'avg_weight': team1_avg_weight,
        }
        
        team2_stats = {
            'total_players': team2.players.count(),
            'positions': team2.players.exclude(position='').values('position').annotate(count=Count('id')),
            'avg_age': team2_avg_age,
            'avg_height': team2_avg_height,
            'avg_weight': team2_avg_weight,
        }
        
        return render(request, 'kbo/team_comparison.html', {
            'teams': teams,
            'team1': team1,
            'team2': team2,
            'team1_stats': team1_stats,
            'team2_stats': team2_stats,
            'team_code1': team_code1,
            'team_code2': team_code2,
        })
    
    return render(request, 'kbo/team_comparison.html', {
        'teams': teams,
    })

def player_detail_modal(request, player_id):
    """선수 상세 정보 모달용 뷰"""
    try:
        player = Player.objects.select_related('team').get(id=player_id)
        
        # 선수 번호 추출 (back_number 필드에서)
        player_number = player.back_number if hasattr(player, 'back_number') and player.back_number else None
        
        # S3에서 이미지 URL 가져오기 (선수 번호 포함하여 정확한 이미지 찾기)
        s3_image_url = get_s3_player_image_url(player.team.code, player.name, player_number)
        if s3_image_url:
            player.image_url = s3_image_url
            # 데이터베이스에도 업데이트
            player.save()
        
        # 이전/다음 선수 정보 가져오기 (팀 전체 기준)
        team_players = player.team.players.all().order_by('back_number', 'name')
        player_list = list(team_players)
        
        current_index = -1
        for i, p in enumerate(player_list):
            if p.id == player.id:
                current_index = i
                break
        
        prev_player = None
        next_player = None
        
        if current_index > 0:
            prev_player = player_list[current_index - 1]
        if current_index < len(player_list) - 1:
            next_player = player_list[current_index + 1]
        
        return render(request, 'kbo/player_detail_modal.html', {
            'player': player,
            'prev_player': prev_player,
            'next_player': next_player,
        })
    except Player.DoesNotExist:
        return JsonResponse({'error': '선수를 찾을 수 없습니다.'}, status=404)

def get_all_players_json(request):
    """모든 선수의 상세 정보를 JSON으로 반환하는 API"""
    players = Player.objects.select_related('team').all()
    data = []
    for p in players:
        data.append({
            'id': p.id,
            'name': p.name,
            'team_name': p.team.name,
            'back_number': p.back_number,
            'position': p.position,
        })
    return JsonResponse({'players': data}, safe=False)