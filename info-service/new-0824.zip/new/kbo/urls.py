from django.urls import path
from django.views.generic import RedirectView
from . import views

urlpatterns = [
    # 루트는 플레이어 메인으로 리디렉션
    path('', RedirectView.as_view(url='/players/', permanent=False)),
    # 메인 플레이어 페이지
    path('players/', views.team_list, name='players_main'),
    # 플레이어 관련 하위 페이지들
    path('players/teams/<str:code>/', views.team_detail, name='team_detail'),
    path('players/search/', views.search_advanced, name='search_advanced'),
    path('players/stats/', views.stats_analysis, name='stats_analysis'),
    path('players/compare/', views.team_comparison, name='team_comparison'),
    path('players/player/<int:player_id>/modal/', views.player_detail_modal, name='player_detail_modal'),
    # API 엔드포인트들
    path('players/api/players/', views.get_all_players_json, name='players_api'),
    path('players/api/team-position-stats/', views.team_position_stats_api, name='team_position_stats_api'),
]