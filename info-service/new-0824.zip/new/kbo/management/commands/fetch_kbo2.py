import time
import shutil
import re
from typing import List, Dict, Optional, Any
from django.core.management.base import BaseCommand
# Chrome 관련 import 제거 (requests 기반으로 변경)
# from selenium import webdriver
# from selenium.webdriver.chrome.options import Options
# from selenium.webdriver.chrome.service import Service
# from selenium.webdriver.common.by import By
# from selenium.webdriver.support.ui import WebDriverWait
# from selenium.webdriver.support import expected_conditions as EC
# from selenium.common.exceptions import TimeoutException, WebDriverException
from bs4 import BeautifulSoup
import requests
from kbo.models import Team, Manager, Player
from datetime import datetime

TEAM_PREFIX_TO_CODE = {
    'LG': 'LG', '두산': 'DS', 'SSG': 'SSG', '롯데': 'LT', 'KIA': 'KIA', '삼성': 'SS', '한화': 'HH', 'NC': 'NC', '키움': 'WO', 'KT': 'KT'
}

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',
    'Accept-Language': 'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7',
}

# Fixed Daum team IDs based on provided URLs
DAUM_TEAM_ID_MAP: Dict[str, int] = {
    'KIA': 389,      # kia (KIA)
    'LG': 387,       # lg (LG)
    'SSG': 384,      # ssg (SSG)
    'LT': 386,       # lotte (롯데)
    'WO': 382,       # kiwoom (키움)
    'KT': 394601,    # kt (KT)
    'NC': 172615,    # nc (NC)
    'DS': 385,       # doosan (두산)
    'SS': 383,       # samsung (삼성)
    'HH': 390,       # hanwha (한화)
}

def build_driver():
    """Chrome 없이도 작동하는 requests 기반 크롤러"""
    return None

def fetch_team_data_with_requests(team_code: str) -> dict:
    """requests를 사용해서 팀 데이터를 가져옵니다"""
    try:
        # KBO 공식 사이트에서 팀 정보 가져오기
        team_url = f"https://www.koreabaseball.com/Team/Player/List.aspx?teamCode={team_code}"
        response = requests.get(team_url, headers=HEADERS, timeout=10)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # 팀명 추출
        team_name_elem = soup.find('h2', class_='team-name') or soup.find('h1') or soup.find('title')
        team_name = team_name_elem.get_text(strip=True) if team_name_elem else f"{team_code} 팀"
        
        # 선수 정보 추출
        players = []
        player_table = soup.find('table', class_='player-list') or soup.find('table')
        
        if player_table:
            for row in player_table.find_all('tr')[1:]:  # 헤더 제외
                cols = row.find_all('td')
                if len(cols) >= 3:
                    player = {
                        'name': cols[1].get_text(strip=True) if len(cols) > 1 else '',
                        'back_number': cols[0].get_text(strip=True) if len(cols) > 0 else '',
                        'position': cols[2].get_text(strip=True) if len(cols) > 2 else '',
                        'bats': '',
                        'throws': ''
                    }
                    if player['name']:  # 이름이 있는 경우만 추가
                        players.append(player)
        
        return {
            'team_name': team_name,
            'players': players
        }
        
    except Exception as e:
        print(f"팀 {team_code} 데이터 가져오기 실패: {e}")
        return {'team_name': f"{team_code} 팀", 'players': []}

def parse_manager_name_from_team_info_html(html: str) -> str:
    soup = BeautifulSoup(html, 'html.parser')
    label = soup.find(lambda t: t.name in ['th', 'dt', 'span', 'strong'] and t.get_text(strip=True) == '감독')
    if label:
        nxt = label.find_next(['td', 'dd', 'span', 'a', 'em'])
        if nxt:
            return nxt.get_text(strip=True)
    blk = soup.find(lambda t: t.name in ['li', 'div', 'p'] and '감독' in t.get_text())
    if blk:
        txt = blk.get_text(' ', strip=True)
        for token in txt.split():
            if '감독' not in token and len(token) >= 2:
                return token
    return ''

def parse_players_from_daum_html(html: str) -> List[dict]:
    soup = BeautifulSoup(html, 'html.parser')
    rows: List[dict] = []
    table = soup.select_one('table.tbl_teamplayer') or soup.find('table', class_='tbl_teamplayer')
    if not table:
        return rows
    for tr in table.select('tbody tr'):
        tds = tr.select('td')
        if len(tds) < 3:
            continue
        back_no = tds[0].get_text(strip=True)
        name = tds[1].get_text(strip=True)
        pos = tds[2].get_text(strip=True)
        rows.append(dict(name=name, back_number=back_no, position=pos, bats='', throws=''))
    return rows

def parse_players_from_daum_html_by_headers(html: str) -> List[dict]:
    soup = BeautifulSoup(html, 'html.parser')
    rows: List[dict] = []
    table = (
        soup.select_one('table.tbl_teamplayer')
        or soup.find('table', class_='tbl_teamplayer')
        or soup.find('table', attrs={'summary': re.compile('선수명단')})
        or soup.find('table')
    )
    if not table:
        return rows
    headers = [th.get_text(strip=True) for th in table.select('thead th')]
    for tr in table.select('tbody tr'):
        tds = tr.select('td')
        if len(tds) < 3:
            continue
        back_no = tds[0].get_text(strip=True)
        name = tds[1].get_text(' ', strip=True)
        pos = tds[2].get_text(strip=True)
        bats = ''
        throws = ''
        if headers:
            for idx, h in enumerate(headers):
                if '투타' in h or '투·타' in h or '투타정보' in h:
                    if idx < len(tds):
                        info = tds[idx].get_text(strip=True)
                        throws = info
                    break
        rows.append(dict(name=name, back_number=back_no, position=pos, bats=bats, throws=throws))
    return rows

def parse_players_from_daum_html_v2(html: str) -> List[Dict]:
    """Daum HTML에서 선수 정보 추출 (v2 방식) - 새로운 구조 대응"""
    soup = BeautifulSoup(html, 'html.parser')
    players = []
    
    # 방법 1: 선수 목록 div 찾기
    player_sections = soup.find_all('div', class_=lambda x: x and ('player' in x.lower() or 'member' in x.lower()))
    
    # 방법 2: 선수 이름이 포함된 요소들 찾기
    if not player_sections:
        player_elements = soup.find_all(['div', 'span', 'a'], text=re.compile(r'[가-힣]{2,4}'))
        for elem in player_elements:
            text = elem.get_text(strip=True)
            # 선수 이름 패턴 (2-4글자 한글, 숫자 제외)
            if re.match(r'^[가-힣]{2,4}$', text) and not text.isdigit():
                # 감독이나 팀명이 아닌지 확인
                if text not in ['감독', '코치', '팀장', '주장'] and len(text) >= 2:
                    players.append({
                        'name': text,
                        'back_number': '',
                        'position': '선수',
                        'height': '',
                        'weight': '',
                        'birthdate': '',
                        'bats_throws': '',
                        'bats': '',
                        'throws': ''
                    })
    
    # 방법 3: 테이블 기반 파싱 (기존 방식)
    if not players:
        tables = soup.find_all('table')
        for table in tables:
            rows = table.find_all('tr')
            for tr in rows:
                tds = tr.find_all(['td', 'th'])
                if len(tds) >= 2:
                    try:
                        # 첫 번째 열이 번호인지 확인
                        first_col = tds[0].get_text(strip=True)
                        if first_col.isdigit() and len(tds) >= 3:
                            back_number = first_col
                            name = tds[1].get_text(strip=True)
                            position = tds[2].get_text(strip=True)
                            
                            if name and name != '이름' and len(name) >= 2:
                                players.append({
                                    'name': name,
                                    'back_number': back_number,
                                    'position': position,
                                    'height': '',
                                    'weight': '',
                                    'birthdate': '',
                                    'bats_throws': '',
                                    'bats': '',
                                    'throws': ''
                                })
                    except Exception as e:
                        continue
    
    # 중복 제거
    unique_players = []
    seen_names = set()
    for player in players:
        if player['name'] not in seen_names:
            unique_players.append(player)
            seen_names.add(player['name'])
    
    return unique_players

def adapt_players_v2_to_rows(players: List[dict]) -> List[dict]:
    """v2 선수 데이터를 기존 형식으로 변환"""
    if not players:
        return []
    
    rows = []
    for player in players:
        # 생년월일 파싱
        birthdate = None
        if player.get('birthdate'):
            try:
                # 다양한 날짜 형식 처리
                date_str = player['birthdate']
                if '-' in date_str:
                    birthdate = datetime.strptime(date_str, '%Y-%m-%d').date()
                elif '.' in date_str:
                    birthdate = datetime.strptime(date_str, '%Y.%m.%d').date()
                elif '/' in date_str:
                    birthdate = datetime.strptime(date_str, '%Y/%m/%d').date()
            except:
                birthdate = None
        
        # 투타 정보 파싱
        bats_throws = player.get('bats_throws', '')
        bats = ''
        throws = ''
        
        if bats_throws:
            if '우투' in bats_throws:
                throws = '우투'
            elif '좌투' in bats_throws:
                throws = '좌투'
            
            if '우타' in bats_throws:
                bats = '우타'
            elif '좌타' in bats_throws:
                bats = '좌타'
            elif '양타' in bats_throws:
                bats = '양타'
        
        rows.append({
            'name': player['name'],
            'back_number': player['back_number'],
            'position': player['position'],
            'height': player['height'],
            'weight': player['weight'],
            'birthdate': birthdate,
            'bats_throws': bats_throws,
            'bats': bats,
            'throws': throws
        })
    
    return rows

def to_code_from_team_name(team_name: str) -> str:
    prefix = team_name.split()[0]
    return TEAM_PREFIX_TO_CODE.get(prefix, '')

def get_html_via_requests(url: str) -> str:
    r = requests.get(url, headers=HEADERS, timeout=20)
    r.raise_for_status()
    return r.text

def extract_stadium_from_html(html: str) -> str:
    soup = BeautifulSoup(html, 'html.parser')
    # Look for labels like '구장', '홈구장'
    label = soup.find(lambda t: t.name in ['span','strong','dt','th'] and t.get_text(strip=True) in ['구장','홈구장'])
    if label:
        nxt = label.find_next(['span','dd','td','em','a'])
        if nxt:
            return nxt.get_text(strip=True)
    # Fallback: text block containing '구장'
    blk = soup.find(lambda t: t.name in ['div','p','li'] and '구장' in t.get_text())
    if blk:
        txt = blk.get_text(' ', strip=True)
        parts = txt.split()
        # choose last token that is not label-like
        for i in range(len(parts)-1, -1, -1):
            if '구장' not in parts[i]:
                return parts[i]
    return ''

class Command(BaseCommand):
    help = 'KBO 팀/감독/선수 최신 데이터 수집 (Daum 사이트만 사용)'

    def add_arguments(self, parser):
        parser.add_argument('--only', type=str, help='특정 팀 코드만(e.g., LG,OB,SSG,...)')
        parser.add_argument('--sleep', type=float, default=0.5, help='요청 간 대기(초)')
        parser.add_argument('--no-browser', action='store_true', help='브라우저 없이 requests로만 수집')

    def handle(self, *args, **opts):
        only = opts.get('only')
        pause = float(opts.get('sleep') or 0.5)
        no_browser = bool(opts.get('no_browser'))

        # 각 팀별로 독립적인 드라이버 사용
        if only:
            # 단일 팀 크롤링
            self.crawl_single_team(only, pause, no_browser)
        else:
            # 전체 팀 크롤링
            self.crawl_all_teams(pause, no_browser)

    def crawl_single_team(self, team_code: str, pause: float, no_browser: bool):
        """단일 팀 크롤링"""
        team_data = [
            ('KIA', 'KIA 타이거즈'),
            ('LG', 'LG 트윈스'),
            ('SSG', 'SSG 랜더스'),
            ('LT', '롯데 자이언츠'),
            ('WO', '키움 히어로즈'),
            ('KT', 'KT 위즈'),
            ('NC', 'NC 다이노스'),
            ('DS', '두산 베어스'),
            ('SS', '삼성 라이온즈'),
            ('HH', '한화 이글스')
        ]
        
        # 해당 팀 찾기
        target_team = None
        for code, name in team_data:
            if code == team_code:
                target_team = (code, name)
                break
        
        if not target_team:
            self.stdout.write(self.style.ERROR(f'팀 코드 {team_code}를 찾을 수 없습니다.'))
            return
        
        self.crawl_team(target_team[0], target_team[1], pause, no_browser)

    def crawl_all_teams(self, pause: float, no_browser: bool):
        """전체 팀 크롤링"""
        team_data = [
            ('KIA', 'KIA 타이거즈'),
            ('LG', 'LG 트윈스'),
            ('SSG', 'SSG 랜더스'),
            ('LT', '롯데 자이언츠'),
            ('WO', '키움 히어로즈'),
            ('KT', 'KT 위즈'),
            ('NC', 'NC 다이노스'),
            ('DS', '두산 베어스'),
            ('SS', '삼성 라이온즈'),
            ('HH', '한화 이글스')
        ]

        for code, team_name in team_data:
            self.crawl_team(code, team_name, pause, no_browser)
            time.sleep(pause)

    def crawl_team(self, code: str, team_name: str, pause: float, no_browser: bool):
        """개별 팀 크롤링"""
        driver = None if no_browser else build_driver()
        
        try:
            # 기존 팀이 있는지 확인 (이름 또는 코드로)
            existing_team = None
            try:
                existing_team = Team.objects.get(code=code)
            except Team.DoesNotExist:
                try:
                    existing_team = Team.objects.get(name=team_name)
                except Team.DoesNotExist:
                    pass
            
            if existing_team:
                # 기존 팀이 있으면 코드와 이름을 모두 업데이트
                existing_team.code = code
                existing_team.name = team_name
                existing_team.save()
                team = existing_team
            else:
                # 새 팀 생성
                team = Team.objects.create(code=code, name=team_name)

            mgr_name: Optional[str] = ''
            rows: List[dict] = []
            daum_id = DAUM_TEAM_ID_MAP.get(code)
            
            if daum_id:
                daum_url = f'https://sports.daum.net/team/kbo/{daum_id}/squad'
                try:
                    # Selenium을 사용해서 JavaScript 실행 후 HTML 가져오기
                    self.stdout.write(f"  🔍 페이지 URL: {daum_url}")
                    
                    if no_browser:
                        # requests 사용 (JavaScript 미실행)
                        response = requests.get(daum_url, headers=HEADERS, timeout=10)
                        response.raise_for_status()
                        html_content = response.text
                        self.stdout.write(f"  ⚠️ requests 사용 (JavaScript 미실행)")
                    else:
                        # Selenium 사용 (JavaScript 실행)
                        try:
                            from selenium import webdriver
                            from selenium.webdriver.chrome.options import Options
                            from selenium.webdriver.common.by import By
                            from selenium.webdriver.support.ui import WebDriverWait
                            from selenium.webdriver.support import expected_conditions as EC
                            from selenium.common.exceptions import TimeoutException, WebDriverException
                            
                            chrome_options = Options()
                            chrome_options.add_argument('--headless')
                            chrome_options.add_argument('--no-sandbox')
                            chrome_options.add_argument('--disable-dev-shm-usage')
                            chrome_options.add_argument('--disable-gpu')
                            chrome_options.add_argument('--window-size=1920,1080')
                            chrome_options.add_argument('--remote-debugging-port=9222')
                            
                            driver = webdriver.Chrome(options=chrome_options)
                            driver.get(daum_url)
                            
                            # JavaScript 실행 대기 (선수 테이블 로딩 대기)
                            wait = WebDriverWait(driver, 15)
                            try:
                                wait.until(EC.presence_of_element_located((By.CLASS_NAME, 'tbl_teamplayer')))
                                self.stdout.write(f"  ✅ JavaScript 실행 완료, 선수 테이블 발견")
                            except TimeoutException:
                                self.stdout.write(f"  ⚠️ 선수 테이블 대기 시간 초과, 현재 HTML 사용")
                            
                            # 4개 포지션 모두 크롤링
                            all_players = []
                            positions = [
                                ('P', '투수'),
                                ('IF', '내야'),
                                ('OF', '외야'),
                                ('C', '포수')
                            ]
                            
                            for pos_code, pos_name in positions:
                                try:
                                    # 포지션 버튼 클릭
                                    pos_button = driver.find_element(By.CSS_SELECTOR, f'[data-position="{pos_code}"]')
                                    driver.execute_script("arguments[0].click();", pos_button)
                                    self.stdout.write(f"  🔄 {pos_name} 포지션 로딩 중...")
                                    
                                    # 데이터 로딩 대기
                                    time.sleep(2)
                                    
                                    # 현재 포지션의 선수 데이터 파싱
                                    current_html = driver.page_source
                                    current_players = parse_players_from_daum_html_v2(current_html)
                                    
                                    if current_players:
                                        self.stdout.write(f"  ✅ {pos_name}: {len(current_players)}명 발견")
                                        # 포지션 정보 추가
                                        for player in current_players:
                                            player['position'] = pos_name
                                        all_players.extend(current_players)
                                    else:
                                        self.stdout.write(f"  ⚠️ {pos_name}: 선수 데이터 없음")
                                        
                                except Exception as e:
                                    self.stdout.write(f"  ❌ {pos_name} 포지션 처리 실패: {e}")
                                    continue
                            
                            # 중복 제거 (같은 이름의 선수)
                            unique_players = []
                            seen_names = set()
                            for player in all_players:
                                if player['name'] not in seen_names:
                                    unique_players.append(player)
                                    seen_names.add(player['name'])
                            
                            self.stdout.write(f"  📊 총 선수 수: {len(unique_players)}명 (중복 제거 후)")
                            
                            # 최종 HTML 저장
                            html_content = driver.page_source
                            driver.quit()
                            
                            # 파싱된 선수 데이터가 있으면 사용
                            if unique_players:
                                players_v2 = unique_players
                                rows = adapt_players_v2_to_rows(unique_players)
                                self.stdout.write(f"  🎯 Selenium으로 {len(unique_players)}명 선수 데이터 추출 완료")
                            
                        except Exception as e:
                            self.stdout.write(f"  ❌ Selenium 실패: {e}, requests로 대체")
                            response = requests.get(daum_url, headers=HEADERS, timeout=10)
                            response.raise_for_status()
                            html_content = response.text
                    
                    # HTML 소스 저장 (디버깅용)
                    debug_file = f"debug_{team.code}_page.html"
                    with open(debug_file, 'w', encoding='utf-8') as f:
                        f.write(html_content)
                    self.stdout.write(f"  💾 HTML 소스 저장: {debug_file}")
                    
                    # 선수 테이블 존재 여부 확인
                    soup = BeautifulSoup(html_content, 'html.parser')
                    tables = soup.find_all('table')
                    self.stdout.write(f"  📊 페이지 내 테이블 수: {len(tables)}")
                    
                    # 선수 데이터 파싱
                    self.stdout.write(f"  🔍 선수 데이터 파싱 시도 중...")
                    
                    # Selenium으로 크롤링한 데이터가 있으면 우선 사용
                    if 'unique_players' in locals() and unique_players:
                        self.stdout.write(f"  🎯 Selenium 크롤링 데이터 사용: {len(unique_players)}명")
                        rows = adapt_players_v2_to_rows(unique_players)
                    else:
                        # Selenium 데이터가 없으면 기존 파싱 방법 사용
                        self.stdout.write(f"  ⚠️ Selenium 데이터 없음, 기존 파싱 방법 사용")
                        
                        # 방법 1: v2 파싱 시도
                        players_v2 = parse_players_from_daum_html_v2(html_content)
                        if players_v2:
                            self.stdout.write(f"  ✅ v2 파싱 성공: {len(players_v2)}명")
                            rows = adapt_players_v2_to_rows(players_v2)
                        else:
                            self.stdout.write(f"  ⚠️ v2 파싱 실패, 헤더 기반 파싱 시도")
                            # 방법 2: 헤더 기반 파싱
                            rows = parse_players_from_daum_html_by_headers(html_content)
                            if rows:
                                self.stdout.write(f"  ✅ 헤더 기반 파싱 성공: {len(rows)}명")
                            else:
                                self.stdout.write(f"  ❌ 모든 파싱 방법 실패")
                    
                    # 디버깅: 실제 HTML에서 선수 관련 텍스트 찾기
                    if not rows:
                        self.stdout.write(f"  🔍 HTML에서 선수 이름 패턴 검색 중...")
                        player_patterns = soup.find_all(text=re.compile(r'[가-힣]{2,4}'))
                        if player_patterns:
                            self.stdout.write(f"  📝 발견된 텍스트 패턴: {len(player_patterns)}개")
                            for i, pattern in enumerate(player_patterns[:5]):  # 처음 5개만
                                self.stdout.write(f"    {i+1}: {pattern.strip()}")
                        else:
                            self.stdout.write(f"  ❌ 선수 이름 패턴도 발견 안됨")
                    
                    # 감독 정보 추출
                    tmp_mgr = parse_manager_name_from_team_info_html(html_content)
                    if tmp_mgr:
                        mgr_name = tmp_mgr
                    
                    # 스타디움 정보 추출
                    stadium = extract_stadium_from_html(html_content) or team.stadium
                    if stadium and stadium != team.stadium:
                        Team.objects.filter(pk=team.pk).update(stadium=stadium)
                    

                except Exception as e:
                    self.stdout.write(f"  ❌ 크롤링 오류: {str(e)}")
                    pass

            if not mgr_name or not rows:
                self.stdout.write(self.style.WARNING(f'{team.name} - 데이터 추출 실패 (Daum에서만 시도)'))

            if mgr_name:
                Manager.objects.update_or_create(team=team, defaults={'name': mgr_name})

            Player.objects.filter(team=team).delete()
            objs = [Player(team=team, **row) for row in rows]
            if objs:
                Player.objects.bulk_create(objs, batch_size=300)

            manager_name_to_log = (mgr_name or Manager.objects.filter(team=team).values_list('name', flat=True).first() or '-')
            self.stdout.write(self.style.SUCCESS(f'{team.name} ✔ (감독:{manager_name_to_log}, 선수:{len(objs)})'))
            
        finally:
            # 각 팀 크롤링 완료 후 드라이버 정리
            if driver:
                try:
                    driver.quit()
                    self.stdout.write(f"  🧹 {team_name} Chrome 드라이버 정리 완료")
                except:
                    pass